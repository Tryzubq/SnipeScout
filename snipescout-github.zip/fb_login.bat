@echo off
setlocal
cd /d "%~dp0"
title SnipeScout - Facebook login
if not exist ".venv\Scripts\python.exe" (
  echo Run start.bat once first, that installs everything.
  pause
  exit /b 1
)
echo Close SnipeScout first if it is running, otherwise the profile is locked.
echo.
".venv\Scripts\python.exe" -m snipescout.fb_login
pause
