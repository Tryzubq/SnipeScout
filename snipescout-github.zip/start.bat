@echo off
setlocal
cd /d "%~dp0"
title SnipeScout

rem ---- Find Python (py launcher first, it is more reliable on Windows) ----
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY (
  where python >nul 2>nul && set "PY=python"
)
if not defined PY goto nopython
%PY% -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul || goto nopython

rem ---- Virtual environment ----
if not exist ".venv\Scripts\python.exe" (
  echo First start: creating virtual environment...
  %PY% -m venv .venv || goto fail
)
set "VPY=.venv\Scripts\python.exe"

rem ---- Packages (again when requirements.txt changed) ----
fc /b requirements.txt .venv\requirements.txt >nul 2>nul
if errorlevel 1 (
  echo Installing packages, this takes a few minutes...
  "%VPY%" -m pip install --upgrade pip >nul
  "%VPY%" -m pip install -r requirements.txt || goto fail
  echo Installing browser for Facebook...
  "%VPY%" -m playwright install chromium || goto fail
  copy /y requirements.txt .venv\requirements.txt >nul
)

rem ---- Create .env on first start ----
if not exist ".env" (
  copy ".env.example" ".env" >nul
  echo.
  echo A .env file was created. Fill in your Telegram token and Gemini key,
  echo save and close Notepad. SnipeScout starts after that.
  notepad ".env"
)

echo.
echo SnipeScout is starting. Close this window to stop.
echo.
"%VPY%" -m snipescout
echo.
echo SnipeScout has stopped.
pause
exit /b 0

:nopython
echo.
echo Python 3.10 or newer was not found.
echo Install Python from python.org and tick "Add python.exe to PATH".
echo Then run start.bat again.
start "" https://www.python.org/downloads/windows/
pause
exit /b 1

:fail
echo.
echo Something went wrong during installation. See the error above.
pause
exit /b 1
