# Troubleshooting

## "It finds nothing"

Open the **Results** tab first. It lists every listing each platform returned in the
last round together with the reason it was or was not alerted, which answers this
question in a few seconds.

The usual causes, in order of likelihood:

| What Results shows | What it means |
|---|---|
| `first round (remembered)` | Normal. A new sniper with *Posted in the last… days* set to **Only new listings** memorises what already exists and alerts only on listings posted from then on. Set a day window if you want a backfill. |
| `already seen` | Handled in an earlier round. |
| `search words not in title` | Your terms are too strict. Check the preview under the search-term field: one long term such as `playstation 5 controller dualsense stick drift` requires **all** of those words in the same title. Separate terms with commas. |
| `outside radius/zone` | The radius is measured from the place in the sniper, which may not be your home location. |
| `too expensive` / `excluded word` | Your own filters. |
| `0 results` on a platform | The platform returned nothing. Try the search term on the site itself; if it works there, the adapter needs updating. |

## Platform-specific

| Symptom | Fix |
|---|---|
| Vinted `HTTP 403` | Temporarily rate-limited. Raise the Vinted interval or untick a few countries. |
| One Vinted country keeps failing | It is paused automatically for 30 minutes and named in the Status tab. |
| Vinted `HTTP 404` | The catalogue endpoint moved again; `platforms/vinted.py` needs updating. |
| Facebook `not logged in` | Close the app and run `fb_login.bat` again. |
| Facebook keeps failing | Set `FB_HEADLESS=false` in `.env` to watch what the browser actually sees. |
| Marktplaats always skipped | Your zone does not overlap the Netherlands, so the search is not even sent. |

## General

| Symptom | Fix |
|---|---|
| `error while attempting to bind on address ('127.0.0.1', 8000)` | Another copy is still running. Close it, or end stray `python.exe` processes, or set `DASHBOARD_PORT=8001`. |
| No Telegram alerts | Settings → Telegram → *Send test alert*. The pairing code changes on every restart until the link is completed. |
| Gemini timeouts or 503 | Google-side overload. The app pauses Gemini for 5 minutes and keeps alerting without it. Lower `GEMINI_MAX_PER_MINUTE` or set `GEMINI_THINKING=minimal`. |
| Alerts stop when the PC sleeps | Disable sleep, or run it on an always-on machine. |

Full detail is written to `data/snipescout.log`.
