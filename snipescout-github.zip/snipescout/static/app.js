"use strict";
let S = null;            // last /api/state
let editing = null;      // sniper id being edited, or 'new'
let map, zoneLayer, homeLayer, drawControl, draftLayer = null;

// ---------- helpers ----------
const $ = (s) => document.querySelector(s);
const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const safeUrl = (u) => (/^https?:\/\//i.test(u || "") ? u : "#");
const euro = (p) => (p === null || p === undefined ? "?" : p === 0 ? "free" : "€" + Math.round(p).toLocaleString("nl-BE"));
const ago = (ts) => {
  if (!ts) return "-";
  const s = Math.round(Date.now() / 1000 - ts);
  if (s < 60) return s + " sec ago";
  if (s < 3600) return Math.round(s / 60) + " min ago";
  if (s < 86400) return Math.round(s / 3600) + " h ago";
  return new Date(ts * 1000).toLocaleString("en-GB");
};
const splitList = (v) => v.split(",").map((x) => x.trim()).filter(Boolean);

function toast(msg, error = false) {
  const t = $("#toast");
  t.textContent = msg;
  t.className = "toast" + (error ? " error" : "");
  clearTimeout(t._h);
  t._h = setTimeout(() => t.classList.add("hidden"), 4000);
}

async function api(path, method = "GET", data) {
  const opt = { method, headers: {} };
  if (method !== "GET") {
    opt.headers["Content-Type"] = "application/json";
    opt.body = JSON.stringify(data || {});
  }
  const r = await fetch(path, opt);
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || "HTTP " + r.status);
  return j;
}

async function guarded(fn) {
  try { await fn(); } catch (e) { toast(e.message, true); }
}

// ---------- tabs ----------
document.querySelectorAll("#tabs button").forEach((b) =>
  b.addEventListener("click", () => {
    document.querySelectorAll("#tabs button").forEach((x) => x.classList.toggle("active", x === b));
    document.querySelectorAll(".tab").forEach((t) => t.classList.toggle("active", t.id === "tab-" + b.dataset.tab));
    if (b.dataset.tab === "map") initMap();
    if (b.dataset.tab === "matches") loadMatches();
    if (b.dataset.tab === "results") loadResults();
    if (b.dataset.tab === "settings") renderSettings(true);
  })
);

// ---------- state ----------
async function refresh() {
  try {
    S = await api("/api/state");
  } catch (e) {
    $("#runState").textContent = "offline";
    return;
  }
  const p = S.settings.paused;
  $("#runState").textContent = p ? "Paused" : "Running";
  $("#runState").className = "pill " + (p ? "off" : "on");
  $("#btnPause").textContent = p ? "Resume" : "Pause";
  renderWarnings();
  if (editing === null) renderSnipers();
  renderStatus();
  renderSettings(false);
  if (map) renderZones();
}

function renderWarnings() {
  const w = [];
  if (!S.telegram.configured) w.push("Telegram is off: put TELEGRAM_BOT_TOKEN in the .env file and restart.");
  else if (!S.telegram.linked) w.push(`Telegram not linked yet: send <b>/start ${esc(S.telegram.pair_code)}</b> to your bot.`);
  if (!S.gemini.configured) w.push("Gemini is off: without GEMINI_API_KEY I only filter on words and price.");
  else if (S.gemini.busy) w.push("Gemini paused (" + esc(S.gemini.busy) + "). Listings are still checked, only without AI.");
  if (!S.geo_loaded) w.push("Postcode list not loaded (no internet on first start?). Zones and distance will not work.");
  $("#warnings").innerHTML = w.map((x) => `<div class="warn">${x}</div>`).join("");
}

// ---------- snipers ----------
function zoneName(id) {
  const z = S.zones.find((z) => z.id === id);
  return z ? z.name : "?";
}

function renderSnipers() {
  const el = $("#sniperList");
  if (!S.snipers.length) {
    el.innerHTML = `<div class="card muted">No snipers yet. Click <b>+ New sniper</b> or send <code>/new iPhone 16 Pro max 450</code> to your bot.</div>`;
    return;
  }
  el.innerHTML = S.snipers.map((s) => {
    const where = s.include_zones.length
      ? s.include_zones.map((z) => `<span class="tag">📍 ${esc(zoneName(z))}</span>`).join("")
      : `<span class="tag">📍 ${esc(s.radius_km || S.settings.default_radius_km)} km around ${esc(s.center_label || "home")}</span>`;
    return `<div class="card sniper ${s.active ? "" : "off"}">
      <div>
        <div class="title">#${s.id} ${esc(s.name)}</div>
        <div>${s.terms.map((t) => `<span class="tag">${esc(t)}</span>`).join("")}</div>
        <div class="muted small">
          ${s.min_price ? euro(s.min_price) + " - " : "up to "}${s.max_price ? euro(s.max_price) : "no max"}
          · ${s.platforms.map((p) => esc(S.platforms[p])).join(", ")}
          · ${s.lookback_days ? "posted in the last " + s.lookback_days + " day(s)" : "new listings only"}${s.use_ai ? " · ✨ score" : ""}
        </div>
        <div>${where}${s.exclude_zones.map((z) => `<span class="tag x">⛔ ${esc(zoneName(z))}</span>`).join("")}
          ${s.exclude.map((w) => `<span class="tag x">not: ${esc(w)}</span>`).join("")}</div>
      </div>
      <div class="row">
        <label class="check"><input type="checkbox" data-toggle="${s.id}" ${s.active ? "checked" : ""}> on</label>
        <button class="ghost small" data-edit="${s.id}">Edit</button>
        <button class="ghost small danger" data-del="${s.id}">Delete</button>
      </div>
    </div>`;
  }).join("");
}

$("#sniperList").addEventListener("click", (e) => {
  const t = e.target;
  if (t.dataset.edit) openForm(+t.dataset.edit);
  if (t.dataset.del && confirm("Delete this sniper?"))
    guarded(async () => { await api(`/api/snipers/${t.dataset.del}`, "DELETE"); await refresh(); });
});
$("#sniperList").addEventListener("change", (e) => {
  const t = e.target;
  if (t.dataset.toggle)
    guarded(async () => { await api(`/api/snipers/${t.dataset.toggle}/active`, "POST", { active: t.checked }); await refresh(); });
});
$("#btnNew").addEventListener("click", () => openForm("new"));

function openForm(id) {
  editing = id;
  const s = id === "new"
    ? { name: "", terms: [], min_price: null, max_price: null, exclude: [], platforms: Object.keys(S.platforms),
        include_zones: [], exclude_zones: [], radius_km: null, lookback_days: 0, strict_match: true, allow_unknown_location: true,
        include_no_price: false, use_ai: true, active: true }
    : S.snipers.find((x) => x.id === id);
  const inc = S.zones.filter((z) => z.kind === "include");
  const exc = S.zones.filter((z) => z.kind === "exclude");
  const f = $("#sniperForm");
  f.classList.remove("hidden");
  f.innerHTML = `
    <h3>${id === "new" ? "New sniper" : "Edit sniper #" + id}</h3>
    <div class="cols">
      <div>
        <label>What are you looking for? (search term)
          <input id="fTerm0" value="${esc(s.terms[0] || "")}" placeholder="e.g. scooter" maxlength="60"></label>
        <label>Extra search terms / synonyms (comma separated)
          <input id="fTerms" value="${esc(s.terms.slice(1).join(", "))}" placeholder="brommer, bromfiets"></label>
        <p class="muted small" id="fPreview" style="margin:-2px 0 10px"></p>
        <div class="row" style="margin:-4px 0 12px">
          <button class="ghost small" id="fSyn" ${S.gemini.configured ? "" : "disabled title='No Gemini key'"}>✨ Synonyms with Gemini</button>
          <span class="muted small">Max 3 to 5 terms: every term is an extra request per round.</span>
        </div>
        <label>Name (optional) <input id="fName" value="${esc(s.name)}" maxlength="80"></label>
        <div class="row">
          <label style="flex:1">Min price € <input id="fMin" type="number" min="0" value="${s.min_price ?? ""}"></label>
          <label style="flex:1">Max price € <input id="fMax" type="number" min="0" value="${s.max_price ?? ""}"></label>
        </div>
        <label>Not if it mentions (comma separated) <input id="fExcl" value="${esc(s.exclude.join(", "))}" placeholder="defect, scherm kapot, onderdelen"></label>
        <p class="muted small" style="margin-top:-6px">Tip: listings are mostly in Dutch, so use Dutch words here.</p>
        <fieldset><legend>Posted</legend>
          <label>Posted in the last … days
            <select id="fDays">
              ${[[0, "Only new listings from now on"], [1, "1 day"], [2, "2 days"], [3, "3 days"], [7, "7 days"], [14, "14 days"], [30, "30 days"]]
                .map(([v, t]) => `<option value="${v}" ${(s.lookback_days || 0) === v ? "selected" : ""}>${t}</option>`).join("")}
            </select></label>
          <p class="muted small">The first round also alerts listings from that period (max ${S.backfill_limit} per search term).
            After that, listings older than this are ignored. Facebook rounds up to 1, 7 or 30 days.
            Vinted usually sends no posting date, so those listings count as recent, newest first.</p>
        </fieldset>
      </div>
      <div>
        <fieldset><legend>Platforms</legend>
          ${Object.entries(S.platforms).map(([k, n]) =>
            `<label class="check"><input type="checkbox" name="fPlat" value="${k}" ${s.platforms.includes(k) ? "checked" : ""}> ${esc(n)}</label>`).join("")}
        </fieldset>
        <fieldset><legend>Where</legend>
          <label class="check"><input type="radio" name="fWhere" value="radius" ${s.include_zones.length ? "" : "checked"}> Radius around a place</label>
          <label class="check"><input type="radio" name="fWhere" value="zones" ${s.include_zones.length ? "checked" : ""} ${inc.length ? "" : "disabled"}> My zones</label>
          <div class="row">
            <label style="flex:2">Around (postcode or town)
              <input id="fCenter" maxlength="60" value="${esc(s.center_label ? s.center_label.replace(/ \(.*\)$/, "") : "")}" placeholder="home: ${esc(S.settings.home_label)}"></label>
            <label style="flex:1">Radius km <input id="fRadius" type="number" min="1" max="300" value="${s.radius_km ?? ""}" placeholder="${S.settings.default_radius_km}"></label>
          </div>
          <p class="muted small" style="margin-top:-6px">Leave empty = around your home location.</p>
          <div>${inc.length ? inc.map((z) => `<label class="check"><input type="checkbox" name="fInc" value="${z.id}" ${s.include_zones.includes(z.id) ? "checked" : ""}> 🟢 ${esc(z.name)}</label>`).join("")
            : '<span class="muted small">No include zones yet. Draw them on the map.</span>'}</div>
          <div>${exc.map((z) => `<label class="check"><input type="checkbox" name="fExc" value="${z.id}" ${s.exclude_zones.includes(z.id) ? "checked" : ""}> 🔴 not in ${esc(z.name)}</label>`).join("")}</div>
          <p class="muted small">Vinted: zones do not apply (shipping).</p>
        </fieldset>
        <fieldset><legend>Options</legend>
          <label class="check"><input type="checkbox" id="fStrict" ${s.strict_match !== false ? "checked" : ""}> Title must contain the search words</label>
          <label class="check"><input type="checkbox" id="fAi" ${s.use_ai ? "checked" : ""}> Gemini bargain score (slower, uses quota)</label>
          <p class="muted small">Gemini never decides whether a listing matches. Your own filters do that,
            so a slow or wrong AI answer can never hide a good deal.</p>
          <label class="check"><input type="checkbox" id="fUnknown" ${s.allow_unknown_location ? "checked" : ""}> Also when location is unknown</label>
          <label class="check"><input type="checkbox" id="fNoPrice" ${s.include_no_price ? "checked" : ""}> Also "make an offer" / no price</label>
          <label class="check"><input type="checkbox" id="fActive" ${s.active ? "checked" : ""}> Active</label>
        </fieldset>
      </div>
    </div>
    <div class="row"><button id="fSave">Save</button><button id="fCancel" class="ghost">Cancel</button></div>`;

  const previewTerms = () => {
    const terms = [$("#fTerm0").value.trim(), ...splitList($("#fTerms").value)].filter(Boolean);
    const blob = $("#fStrict").checked && terms.some((t) => t.split(/\s+/).length > 3);
    $("#fPreview").innerHTML = terms.length
      ? "Searches for: " + terms.map((t) => `<span class="tag">${esc(t)}</span>`).join("") +
        (blob ? '<br><span class="err">A term with that many words will almost never match. Separate terms with commas.</span>' : "")
      : '<span class="err">Enter at least one search term.</span>';
  };
  ["#fTerm0", "#fTerms", "#fStrict"].forEach((id) => { $(id).oninput = previewTerms; $(id).onchange = previewTerms; });
  previewTerms();

  $("#fCancel").onclick = closeForm;
  $("#fSyn").onclick = () => guarded(async () => {
    const term = $("#fTerm0").value.trim();
    if (!term) throw new Error("Enter a search term first");
    $("#fSyn").textContent = "Thinking (can take 10-30 sec)…";
    try {
      const r = await api("/api/synonyms", "POST", { term });
      $("#fTerms").value = r.terms.slice(1).join(", ");
      previewTerms();
    } finally { $("#fSyn").textContent = "✨ Synonyms with Gemini"; }
  });
  $("#fSave").onclick = () => guarded(async () => {
    const vals = (n) => [...document.querySelectorAll(`input[name=${n}]:checked`)].map((x) => x.value);
    const useZones = document.querySelector("input[name=fWhere]:checked").value === "zones";
    const data = {
      name: $("#fName").value.trim(),
      terms: [$("#fTerm0").value.trim(), ...splitList($("#fTerms").value)].filter(Boolean),
      min_price: $("#fMin").value || null,
      max_price: $("#fMax").value || null,
      exclude: splitList($("#fExcl").value),
      platforms: vals("fPlat"),
      include_zones: useZones ? vals("fInc").map(Number) : [],
      exclude_zones: vals("fExc").map(Number),
      radius_km: $("#fRadius").value || null,
      center_query: $("#fCenter").value.trim(),
      lookback_days: Number($("#fDays").value),
      strict_match: $("#fStrict").checked,
      use_ai: $("#fAi").checked,
      allow_unknown_location: $("#fUnknown").checked,
      include_no_price: $("#fNoPrice").checked,
      active: $("#fActive").checked,
    };
    if (useZones && !data.include_zones.length) throw new Error("Choose at least one zone");
    if (editing === "new") await api("/api/snipers", "POST", data);
    else await api(`/api/snipers/${editing}`, "PUT", data);
    toast(data.lookback_days
      ? `Saved. The first round also alerts listings from the last ${data.lookback_days} day(s).`
      : "Saved. The first round remembers existing listings, after that you only get new ones.");
    closeForm();
    await refresh();
  });
  f.scrollIntoView({ behavior: "smooth" });
}

function closeForm() {
  editing = null;
  $("#sniperForm").classList.add("hidden");
  renderSnipers();
}

// ---------- map ----------
function initMap() {
  if (map) { setTimeout(() => map.invalidateSize(), 50); return; }
  if (!window.L) { toast("Map could not load (no internet?)", true); return; }
  map = L.map("map").setView([S.settings.home_lat, S.settings.home_lng], 10);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 18, attribution: "&copy; OpenStreetMap",
  }).addTo(map);
  zoneLayer = new L.FeatureGroup().addTo(map);
  homeLayer = new L.FeatureGroup().addTo(map);
  drawControl = new L.Control.Draw({
    draw: { polygon: { allowIntersection: false, showArea: false, shapeOptions: { color: "#3ccf7a" } },
            polyline: false, rectangle: { shapeOptions: { color: "#3ccf7a" } }, circle: false, marker: false, circlemarker: false },
    edit: { featureGroup: zoneLayer, remove: false },
  });
  map.addControl(drawControl);

  map.on(L.Draw.Event.CREATED, (e) => {
    if (draftLayer) map.removeLayer(draftLayer);
    draftLayer = e.layer.addTo(map);
    $("#zoneDraft").classList.remove("hidden");
    $("#zName").value = "";
    $("#zName").focus();
  });
  map.on(L.Draw.Event.EDITED, (e) => {
    e.layers.eachLayer((layer) => guarded(async () => {
      const z = S.zones.find((x) => x.id === layer.zoneId);
      await api(`/api/zones/${z.id}`, "PUT", { name: z.name, kind: z.kind, coords: coordsOf(layer) });
      toast("Zone updated");
      await refresh();
    }));
  });
  setTimeout(() => map.invalidateSize(), 50);
  renderZones();
}

const coordsOf = (layer) => layer.getLatLngs()[0].map((p) => [p.lat, p.lng]);

$("#zSave").onclick = () => guarded(async () => {
  if (!draftLayer) return;
  await api("/api/zones", "POST", { name: $("#zName").value.trim() || "Zone", kind: $("#zKind").value, coords: coordsOf(draftLayer) });
  map.removeLayer(draftLayer); draftLayer = null;
  $("#zoneDraft").classList.add("hidden");
  toast("Zone saved. Link it to a sniper via Edit.");
  await refresh();
});
$("#zCancel").onclick = () => {
  if (draftLayer) map.removeLayer(draftLayer);
  draftLayer = null;
  $("#zoneDraft").classList.add("hidden");
};

let zoneSig = "";
function renderZones() {
  const sig = JSON.stringify([S.zones, S.settings.home_lat, S.settings.home_lng, S.settings.default_radius_km,
    S.snipers.map((x) => [x.active, x.center_lat, x.center_lng, x.radius_km])]);
  if (sig === zoneSig) return;   // do not redraw while editing
  zoneSig = sig;
  zoneLayer.clearLayers();
  homeLayer.clearLayers();
  const home = [S.settings.home_lat, S.settings.home_lng];
  L.circle(home, { radius: S.settings.default_radius_km * 1000, color: "#4ea3ff", weight: 1, fillOpacity: 0.04, interactive: false }).addTo(homeLayer);
  L.marker(home).bindTooltip("Home: " + esc(S.settings.home_label)).addTo(homeLayer);
  for (const sn of S.snipers) {
    if (!sn.active || sn.include_zones.length || sn.center_lat == null) continue;
    L.circle([sn.center_lat, sn.center_lng], { radius: (sn.radius_km || S.settings.default_radius_km) * 1000,
      color: "#ffb36b", weight: 1, dashArray: "4 4", fillOpacity: 0.03, interactive: false }).addTo(homeLayer);
  }
  for (const z of S.zones) {
    const color = z.kind === "include" ? "#3ccf7a" : "#ff5d5d";
    const layer = L.polygon(z.coords, { color, weight: 2, fillOpacity: 0.15 });
    layer.zoneId = z.id;
    layer.bindTooltip(esc(z.name));
    zoneLayer.addLayer(layer);
  }
  $("#zoneList").innerHTML = S.zones.length ? S.zones.map((z) => `
    <div class="zone ${z.kind}" data-focus="${z.id}">
      <span>${z.kind === "include" ? "🟢" : "🔴"} ${esc(z.name)}</span>
      <span class="row">
        <button class="ghost small" data-kind="${z.id}">${z.kind === "include" ? "→ exclude" : "→ include"}</button>
        <button class="ghost small danger" data-zdel="${z.id}">✕</button>
      </span>
    </div>`).join("") : '<p class="muted">No zones yet.</p>';
}

$("#zoneList").addEventListener("click", (e) => {
  const t = e.target;
  if (t.dataset.zdel) {
    if (confirm("Delete this zone? It is also removed from your snipers."))
      guarded(async () => { await api(`/api/zones/${t.dataset.zdel}`, "DELETE"); await refresh(); });
    return;
  }
  if (t.dataset.kind) {
    const z = S.zones.find((x) => x.id === +t.dataset.kind);
    guarded(async () => {
      await api(`/api/zones/${z.id}`, "PUT", { name: z.name, kind: z.kind === "include" ? "exclude" : "include", coords: z.coords });
      await refresh();
    });
    return;
  }
  const row = t.closest("[data-focus]");
  if (row) {
    const z = S.zones.find((x) => x.id === +row.dataset.focus);
    map.fitBounds(L.polygon(z.coords).getBounds(), { padding: [30, 30] });
  }
});

// ---------- matches ----------
async function loadMatches() {
  await guarded(async () => {
    const r = await api("/api/matches?status=match");
    const g = $("#matchGrid");
    if (!r.matches.length) { g.innerHTML = '<p class="muted">Nothing yet. New listings show up here and in Telegram.</p>'; return; }
    g.innerHTML = r.matches.map((m) => {
      const cls = m.score >= 7 ? "hi" : m.score >= 4 ? "mid" : "lo";
      return `<div class="card match">
        ${m.image ? `<img src="${esc(safeUrl(m.image))}" loading="lazy" referrerpolicy="no-referrer" alt="">` : ""}
        <div class="body">
          <div class="row between"><span class="price">${euro(m.price)}</span>${m.score ? `<span class="score ${cls}">${m.score}/10</span>` : ""}</div>
          <div><b>${esc(m.title)}</b></div>
          <div class="muted small">${[S.platforms[m.platform] || m.platform, m.location, ago(m.ts)].filter(Boolean).map(esc).join(" · ")}</div>
          <div class="muted small">🎯 ${esc(m.sniper_name || "")}</div>
          ${m.reason ? `<div class="small"><i>${esc(m.reason)}</i></div>` : ""}
          <a class="open" href="${esc(safeUrl(m.url))}" target="_blank" rel="noopener noreferrer">Open listing</a>
        </div></div>`;
    }).join("");
  });
}
$("#btnClear").onclick = () => {
  if (confirm("Clear all matches? (The seen list stays, so you will not get duplicate alerts.)"))
    guarded(async () => { await api("/api/matches/clear", "POST"); await loadMatches(); });
};

// ---------- results ----------
const SEEN = ["already seen", "first round (remembered)"];
function postedText(ts) {
  if (!ts) return "";
  const age = Date.now() / 1000 - ts;
  if (age < 0) return "posted today";            // only the day is known (end of that day)
  if (age < 86400) return "posted " + ago(ts);
  return "posted " + Math.round(age / 86400) + " day(s) ago";
}
function verdictClass(v) {
  if (v === "alert") return "alert";
  if (v === "rejected by Gemini") return "gemini";
  if (SEEN.includes(v) || v.startsWith("first round")) return "";
  return "filter";
}

async function loadResults() {
  await guarded(async () => {
    const r = await api("/api/results");
    // fill filters once with the current snipers/platforms, keep the selection
    const sSel = $("#rSniper"), pSel = $("#rPlatform");
    const keepS = sSel.value, keepP = pSel.value;
    sSel.innerHTML = '<option value="">All snipers</option>' +
      S.snipers.map((s) => `<option value="${s.id}">#${s.id} ${esc(s.name)}</option>`).join("");
    pSel.innerHTML = '<option value="">All platforms</option>' +
      Object.entries(S.platforms).map(([k, n]) => `<option value="${k}">${esc(n)}</option>`).join("");
    sSel.value = keepS; pSel.value = keepP;

    const vf = $("#rVerdict").value;
    const groups = r.results.filter((g) => (!keepS || g.sniper_id === +keepS) && (!keepP || g.platform === keepP));
    if (!groups.length) {
      $("#resultsBody").innerHTML = '<p class="muted">No results yet. Click <b>Search now</b> and wait a minute.</p>';
      return;
    }
    $("#resultsBody").innerHTML = groups.map((g) => {
      const items = g.items.filter((i) =>
        !vf || (vf === "alert" && i.verdict === "alert") || (vf === "new" && !SEEN.includes(i.verdict)) ||
        (vf === "skipped" && i.verdict !== "alert"));
      const nAlert = g.items.filter((i) => i.verdict === "alert").length;
      return `<div class="rgroup"><h3>#${g.sniper_id} ${esc(g.sniper_name)} · ${esc(S.platforms[g.platform] || g.platform)}</h3>
          <span class="muted small">${g.items.length} results · ${nAlert} alerts · ${ago(g.ts)}${g.note ? " · " + esc(g.note) : ""}</span></div>
        ${items.length ? `<div class="rgrid">${items.map((i) => `
          <a class="card ritem" href="${esc(safeUrl(i.url))}" target="_blank" rel="noopener noreferrer">
            ${i.image ? `<img src="${esc(safeUrl(i.image))}" loading="lazy" referrerpolicy="no-referrer" alt="">` : '<div class="noimg"></div>'}
            <div class="info">
              <div class="t" title="${esc(i.title)}">${esc(i.title)}</div>
              <div class="small"><span class="p">${euro(i.price)}</span>
                <span class="muted">${[i.location, postedText(i.posted_at)].filter(Boolean).map(esc).join(" · ")}</span>
                ${i.score ? `<span class="muted"> · ${i.score}/10</span>` : ""}</div>
              <span class="verdict ${verdictClass(i.verdict)}" title="${esc(i.detail || "")}">${i.verdict === "alert" ? "✓ alert sent" : esc(i.verdict)}${i.detail && i.verdict !== "alert" && i.detail !== i.verdict ? ": " + esc(i.detail) : ""}</span>
            </div>
          </a>`).join("")}</div>` : '<p class="muted small">Nothing matches this filter.</p>'}`;
    }).join("");
  });
}
["#rSniper", "#rPlatform", "#rVerdict"].forEach((id) => ($(id).onchange = loadResults));

// ---------- status ----------
function renderStatus() {
  $("#statusBody").innerHTML = Object.entries(S.status).map(([k, st]) => `
    <tr><td><b>${esc(S.platforms[k])}</b></td>
      <td class="${st.error ? "err" : ""}">${esc(st.summary)}</td>
      <td>${S.settings.paused ? "-" : st.next_in + " sec"}</td>
      <td>${st.found}</td></tr>`).join("");
}

// ---------- settings ----------
function renderSettings(force) {
  const s = S.settings;
  $("#sHomeLabel").textContent = "Current home location: " + s.home_label + ", radius " + s.default_radius_km + " km";
  if (!force) { renderSettingsStatus(); return; }  // fill inputs only when opening or after saving, otherwise your input is lost
  $("#sHome").value = s.home_query;
  $("#sRadius").value = s.default_radius_km;
  $("#sFb").value = s.fb_location || "";
  const picked = s.vinted_countries || Object.keys(S.vinted_sites);
  $("#sVinted").innerHTML = Object.entries(S.vinted_sites).map(([c, label]) =>
    `<label class="check"><input type="checkbox" data-vc="${c}" ${picked.includes(c) ? "checked" : ""}> ${esc(label)}</label>`).join("");
  $("#sIntervals").innerHTML = Object.entries(S.platforms).map(([k, n]) =>
    `<label>${esc(n)} (min ${S.min_interval[k]}) <input type="number" data-int="${k}" min="${S.min_interval[k]}" max="3600" value="${s.intervals[k]}"></label>`).join("");
  renderSettingsStatus();
}

let tgSig = "";
function renderSettingsStatus() {
  const t = S.telegram;
  const sig = JSON.stringify([t, S.gemini]);
  if (sig === tgSig) return;
  tgSig = sig;
  $("#sTelegram").innerHTML = !t.configured
    ? '<p class="err">No token. Put TELEGRAM_BOT_TOKEN in .env and restart.</p>'
    : t.linked
      ? '<p>✅ Linked.</p><div class="row"><button id="tTest">Send test alert</button><button id="tUnlink" class="ghost danger">Unlink</button></div>'
      : `<p>Send this to your bot in Telegram:</p><p class="code">/start ${esc(t.pair_code)}</p>`;
  if ($("#tTest")) $("#tTest").onclick = () => guarded(async () => { await api("/api/telegram/test", "POST"); toast("Sent"); });
  if ($("#tUnlink")) $("#tUnlink").onclick = () => guarded(async () => { await api("/api/settings", "POST", { unlink_telegram: true }); await refresh(); });
  $("#sGemini").innerHTML = S.gemini.configured
    ? `<p>✅ Active, model <code>${esc(S.gemini.model)}</code>.</p><p class="muted small">Set the limit per minute with GEMINI_MAX_PER_MINUTE in .env.</p>`
    : '<p class="err">No key. Put GEMINI_API_KEY in .env and restart.</p>';
}

$("#sSaveHome").onclick = () => guarded(async () => {
  await api("/api/settings", "POST", { home_query: $("#sHome").value, default_radius_km: $("#sRadius").value });
  toast("Saved"); await refresh(); renderSettings(true);
});
$("#sSaveIntervals").onclick = () => guarded(async () => {
  const iv = {};
  document.querySelectorAll("[data-int]").forEach((i) => (iv[i.dataset.int] = i.value));
  await api("/api/settings", "POST", { intervals: iv });
  toast("Saved"); await refresh(); renderSettings(true);
});
$("#sSaveVinted").onclick = () => guarded(async () => {
  const codes = [...document.querySelectorAll("[data-vc]:checked")].map((i) => i.dataset.vc);
  await api("/api/settings", "POST", { vinted_countries: codes });
  toast("Saved"); await refresh(); renderSettings(true);
});
$("#sSaveFb").onclick = () => guarded(async () => {
  await api("/api/settings", "POST", { fb_location: $("#sFb").value });
  toast("Saved"); await refresh(); renderSettings(true);
});

// ---------- header ----------
$("#btnPause").onclick = () => guarded(async () => { await api("/api/settings", "POST", { paused: !S.settings.paused }); await refresh(); });
$("#btnRun").onclick = () => guarded(async () => { await api("/api/run", "POST"); toast("Search round started"); });

refresh();
setInterval(refresh, 5000);
setInterval(() => {
  if ($("#tab-matches").classList.contains("active")) loadMatches();
  if ($("#tab-results").classList.contains("active")) loadResults();
}, 20000);
