"""Start: python -m snipescout"""
import asyncio
import logging
import sys
import webbrowser

import uvicorn

from . import ai, config, db, geo, telegram, web
from .scheduler import Scheduler

LOG_FILE = config.DATA_DIR / "snipescout.log"


def setup_logging():
    fmt = logging.Formatter("%(asctime)s %(levelname)-7s %(name)s: %(message)s", "%H:%M:%S")
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    for h in (logging.StreamHandler(sys.stdout), logging.FileHandler(LOG_FILE, encoding="utf-8")):
        h.setFormatter(fmt)
        root.addHandler(h)
    for noisy in ("uvicorn.access", "httpx"):
        logging.getLogger(noisy).setLevel(logging.WARNING)


async def housekeeping():
    while True:
        await asyncio.sleep(6 * 3600)
        db.prune()


async def main():
    setup_logging()
    log = logging.getLogger("snipescout")
    db.conn()
    # 2.0.2: dates of 2dehands/Marktplaats were not read before, so snipers with
    # 'posted in the last X days' skipped everything. Run their first round once more.
    if not db.get_settings().get("date_fix_202"):
        for s in db.list_snipers():
            if s["lookback_days"]:
                db.reset_for_backfill(s["id"])
        db.set_setting("date_fix_202", True)
    await asyncio.to_thread(geo.load)

    log.info("Telegram: %s", "on" if telegram.enabled() else "OFF (no token in .env)")
    log.info("Gemini:   %s", f"on ({config.GEMINI_MODEL})" if ai.enabled() else "OFF (no key in .env)")
    if telegram.enabled() and not telegram.chat_id():
        log.info("Link Telegram: send  /start %s  to your bot", telegram.PAIR_CODE)

    sched = Scheduler()
    web.SCHEDULER = sched
    sched.start()
    tasks = [asyncio.create_task(telegram.poll_loop(sched)), asyncio.create_task(housekeeping())]

    server = uvicorn.Server(uvicorn.Config(web.build_app(), host="127.0.0.1", port=config.PORT,
                                           log_level="warning"))
    url = f"http://localhost:{config.PORT}"
    log.info("Dashboard: %s  (close this window to stop)", url)
    if "--no-browser" not in sys.argv:
        webbrowser.open(url)
    try:
        await server.serve()
    finally:
        for t in tasks:
            t.cancel()
        await sched.stop()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
