"""Opens a visible browser so you can log in to Facebook once.
The session is stored in data/fb_profile. Never share that folder."""
import asyncio

from playwright.async_api import async_playwright

from . import config


async def main():
    config.FB_PROFILE_DIR.mkdir(parents=True, exist_ok=True)
    async with async_playwright() as pw:
        ctx = await pw.chromium.launch_persistent_context(
            str(config.FB_PROFILE_DIR), headless=False, locale="nl-BE",
            viewport={"width": 1280, "height": 900})
        page = ctx.pages[0] if ctx.pages else await ctx.new_page()
        await page.goto("https://www.facebook.com/marketplace/")
        print()
        print("1. Log in to Facebook in the window that opened (preferably a separate account).")
        print("2. Go to Marketplace and set your location and radius.")
        print("3. Copy the part after /marketplace/ from the address bar (e.g. 'gent' or '1234567890')")
        print("   and paste it in the dashboard under Settings > Facebook location.")
        print()
        input("Press Enter when you are done to close the window...")
        await ctx.close()


if __name__ == "__main__":
    asyncio.run(main())
