"""Telegram: send alerts and receive commands (long polling, no open port needed).
Only the linked chat may give commands. Linking is done with /start <code>."""
import asyncio
import html
import logging
import re
import secrets

from . import ai, config, db
from .net import Client

log = logging.getLogger("telegram")
API = "https://api.telegram.org/bot{token}/{method}"

_client = Client()
_poll_client = Client()
PAIR_CODE = f"{secrets.randbelow(10**6):06d}"
_fail = {"n": 0}

HELP = """<b>SnipeScout commands</b>
/new iPhone 16 Pro max 450 not broken, cracked screen
/new scooter min 200 max 900 days 3
/list  all snipers
/on 3  /off 3  /delete 3
/pause  /resume  stop or resume everything
/status  last round per platform

<i>days 3</i> = also alert listings from the last 3 days on the first round."""

# old Dutch commands keep working
ALIASES = {"/nieuw": "/new", "/lijst": "/list", "/aan": "/on", "/uit": "/off",
           "/verwijder": "/delete", "/pauze": "/pause", "/hervat": "/resume"}


def enabled() -> bool:
    return bool(config.TELEGRAM_TOKEN)


def chat_id():
    return db.get_settings().get("telegram_chat_id")


async def call(method: str, client: Client = _client, http_timeout: int = 25, **payload):
    # note: 'timeout' in payload is the Telegram parameter, http_timeout is the HTTP wait time
    if not enabled():
        return None
    r = await client.post(API.format(token=config.TELEGRAM_TOKEN, method=method), json=payload,
                          timeout=http_timeout)
    data = r.json()
    if not data.get("ok"):
        raise RuntimeError(data.get("description", "unknown error"))
    return data["result"]


async def send(text: str, chat=None):
    chat = chat or chat_id()
    if not chat:
        return
    try:
        await call("sendMessage", chat_id=chat, text=text[:4000], parse_mode="HTML",
                   disable_web_page_preview=True)
    except Exception as e:
        log.warning("sending message failed: %s", e)


def _price(p) -> str:
    if p is None:
        return "price unknown"
    return "free" if p == 0 else f"€{p:,.0f}".replace(",", ".")


async def notify_match(sniper: dict, listing, score: int | None, reason: str):
    chat = chat_id()
    if not chat:
        return
    name = config.PLATFORMS.get(listing.platform, listing.platform)
    stars = f"🔥 Bargain score <b>{score}/10</b>" if score else ""
    caption = (
        f"<b>{html.escape(listing.title[:150])}</b>\n"
        f"💶 <b>{_price(listing.price)}</b> · {html.escape(name)}"
        f"{' · 📍 ' + html.escape(listing.location) if listing.location else ''}\n"
        f"{stars}\n"
        f"{('<i>' + html.escape(reason) + '</i>' + chr(10)) if reason else ''}"
        f"🎯 Sniper: {html.escape(sniper['name'])}"
    )
    markup = {"inline_keyboard": [[{"text": "Open listing", "url": listing.url}]]}
    try:
        if listing.image:
            await call("sendPhoto", chat_id=chat, photo=listing.image, caption=caption[:1024],
                       parse_mode="HTML", reply_markup=markup)
            return
    except Exception as e:
        log.info("sending photo failed (%s), sending text", e)
    try:
        await call("sendMessage", chat_id=chat, text=caption, parse_mode="HTML", reply_markup=markup)
    except Exception as e:
        log.warning("alert failed: %s", e)


# ---------- commands ----------

NUM = r"\d+(?:[.,]\d+)?"
NEW_RE = re.compile(
    rf"^(?P<q>.+?)(?:\s+min\s+(?P<min>{NUM}))?\s+max\s+(?P<max>{NUM})"
    r"(?:\s+(?:days|dagen)\s+(?P<days>\d+))?"
    r"(?:\s+(?:not|niet)\s+(?P<not>.+))?$", re.I)


def parse_new(text: str) -> dict | None:
    m = NEW_RE.match(text.strip())
    if not m:
        return None
    num = lambda s: float(s.replace(",", ".")) if s else None  # noqa: E731
    excl = [w.strip() for w in (m.group("not") or "").split(",") if w.strip()]
    days = min(int(m.group("days")), 30) if m.group("days") else 0
    return {"q": m.group("q").strip(), "min": num(m.group("min")), "max": num(m.group("max")),
            "days": days, "exclude": excl}


async def handle(text: str, chat, scheduler) -> str:
    parts = text.strip().split(maxsplit=1)
    cmd = parts[0].split("@")[0].lower()
    cmd = ALIASES.get(cmd, cmd)
    arg = parts[1] if len(parts) > 1 else ""

    if cmd in ("/help", "/start"):
        return HELP
    if cmd == "/new":
        p = parse_new(arg)
        if not p:
            return "Usage: /new iPhone 16 Pro max 450 days 3 not broken, cracked screen"
        terms = await ai.synonyms(p["q"]) if ai.enabled() else [p["q"]]
        sid = db.save_sniper({
            "name": p["q"][:80], "terms": terms, "min_price": p["min"], "max_price": p["max"],
            "exclude": p["exclude"], "platforms": list(config.PLATFORMS), "include_zones": [],
            "exclude_zones": [], "radius_km": None, "lookback_days": p["days"],
            "allow_unknown_location": True, "include_no_price": False, "use_ai": True, "active": True})
        first = (f"First round also alerts listings from the last {p['days']} day(s)."
                 if p["days"] else "First round remembers existing listings, after that you only get new ones.")
        return (f"✅ Sniper #{sid} created\nSearching for: {html.escape(', '.join(terms))}\n"
                f"Max €{p['max']:.0f}. Change zones and platforms in the dashboard.\n{first}")
    if cmd == "/list":
        rows = db.list_snipers()
        if not rows:
            return "No snipers yet. Create one with /new"
        return "\n".join(
            f"{'🟢' if s['active'] else '⚪'} #{s['id']} {html.escape(s['name'])} · max "
            f"{'€%.0f' % s['max_price'] if s['max_price'] else '-'}"
            f"{' · last %d days' % s['lookback_days'] if s['lookback_days'] else ''}" for s in rows)
    if cmd in ("/on", "/off", "/delete"):
        if not arg.strip().lstrip("#").isdigit():
            return f"Usage: {cmd} <number>"
        sid = int(arg.strip().lstrip("#"))
        if not db.get_sniper(sid):
            return "Sniper not found"
        if cmd == "/delete":
            db.delete_sniper(sid)
            return f"🗑 Sniper #{sid} deleted"
        db.set_active(sid, cmd == "/on")
        return f"Sniper #{sid} {'on' if cmd == '/on' else 'off'}"
    if cmd in ("/pause", "/resume"):
        db.set_setting("paused", cmd == "/pause")
        return "⏸ Paused" if cmd == "/pause" else "▶️ Resumed"
    if cmd == "/status":
        lines = ["⏸ PAUSED" if db.get_settings()["paused"] else "▶️ Running"]
        for k, st in scheduler.status.items():
            lines.append(f"{config.PLATFORMS[k]}: {st.get('summary', 'not run yet')}")
        return "\n".join(lines)
    return "Unknown command. /help for the list."


async def poll_loop(scheduler):
    global PAIR_CODE
    if not enabled():
        log.info("No TELEGRAM_BOT_TOKEN: Telegram is off")
        return
    offset = None
    while True:
        try:
            payload = {"timeout": 25, "allowed_updates": ["message"]}
            if offset:
                payload["offset"] = offset
            updates = await call("getUpdates", client=_poll_client, http_timeout=35, **payload)
            for u in updates or []:
                offset = u["update_id"] + 1
                msg = u.get("message") or {}
                text = msg.get("text") or ""
                chat = (msg.get("chat") or {}).get("id")
                if not text or not chat:
                    continue
                current = chat_id()
                if current is None:
                    if text.strip() == f"/start {PAIR_CODE}":
                        db.set_setting("telegram_chat_id", chat)
                        await send("✅ Linked! You will get your alerts here.\n\n" + HELP, chat)
                    else:
                        _fail["n"] += 1
                        if _fail["n"] >= 10:  # against guessing: new code after 10 wrong attempts
                            PAIR_CODE = f"{secrets.randbelow(10**6):06d}"
                            _fail["n"] = 0
                            log.warning("Too many wrong link attempts, new code: %s", PAIR_CODE)
                        await send("Send /start followed by the code from the dashboard.", chat)
                    continue
                if chat != current:
                    continue  # ignore strangers
                try:
                    reply = await handle(text, chat, scheduler)
                except Exception as e:
                    log.exception("command error")
                    reply = f"Error: {html.escape(str(e))}"
                await send(reply, chat)
        except asyncio.CancelledError:
            raise
        except Exception as e:
            log.warning("Telegram polling error: %s", e)
            await asyncio.sleep(10)
