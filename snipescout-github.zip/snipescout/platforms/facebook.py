"""Facebook Marketplace via Playwright with a saved, logged-in browser profile.
Log in once with fb_login.bat first. Use a separate account: scraping is against
Facebook's terms and can get the account blocked."""
import asyncio
import logging
import re
from urllib.parse import quote

from .. import config, db
from . import Blocked, Listing

log = logging.getLogger("facebook")

PRICE_RE = re.compile(r"€\s?([\d.\s ]+(?:,\d{1,2})?)")

EXTRACT_JS = r"""
() => {
  const seen = new Set(); const out = [];
  for (const a of document.querySelectorAll('a[href*="/marketplace/item/"]')) {
    const m = a.href.match(/\/marketplace\/item\/(\d+)/);
    if (!m || seen.has(m[1])) continue;
    seen.add(m[1]);
    const img = a.querySelector('img');
    const lines = (a.innerText || '').split('\n').map(s => s.trim()).filter(Boolean);
    out.push({id: m[1], img: img ? img.src : '', alt: img ? (img.alt || '') : '', lines});
  }
  return out;
}
"""


def parse_price(text: str) -> float | None:
    low = text.lower()
    if low in ("gratis", "free"):
        return 0.0
    m = PRICE_RE.search(text)
    if not m:
        return None
    num = re.sub(r"[.\s ]", "", m.group(1)).replace(",", ".")
    try:
        return float(num)
    except ValueError:
        return None


LOCATION_RE = re.compile(r"^[^,\d€]{2,40},\s?[A-Z]{2,4}$")      # 'Hasselt, VLG', 'Charleroi, WAL'
MILEAGE_RE = re.compile(r"^[\d.\s]+\s?(km|mi)\b", re.I)


def parse_card(card: dict) -> Listing:
    """Card text is usually: price, title, location, (mileage). Some layouts drop the title,
    so every line is classified instead of relying on its position."""
    price, title, location = None, "", ""
    for line in card["lines"]:
        p = parse_price(line)
        if p is not None:
            if price is None:
                price = p
            continue
        if LOCATION_RE.match(line):
            location = location or line
        elif MILEAGE_RE.match(line):
            continue
        elif not title:
            title = line
    if not title:
        # the image alt text often holds the title, sometimes followed by ' in <town>'
        alt = card.get("alt", "").strip()
        title = re.split(r"\s+in\s+[^,]+,\s?[A-Z]{2,4}$", alt)[0].strip() if alt else ""
    return Listing(
        uid=f"fb:{card['id']}",
        platform="facebook",
        title=title or "(no title)",
        url=f"https://www.facebook.com/marketplace/item/{card['id']}/",
        price=price,
        image=card.get("img", ""),
        location=location,
    )


class Facebook:
    key = "facebook"

    def __init__(self):
        self._pw = None
        self._ctx = None
        self._page = None
        self._lock = asyncio.Lock()

    async def _ensure(self):
        if self._page and not self._page.is_closed():
            return
        from playwright.async_api import async_playwright
        if not (config.FB_PROFILE_DIR / "Default").exists() and not any(config.FB_PROFILE_DIR.glob("*")):
            raise Blocked("not logged in: run fb_login.bat first")
        self._pw = await async_playwright().start()
        self._ctx = await self._pw.chromium.launch_persistent_context(
            str(config.FB_PROFILE_DIR), headless=config.FB_HEADLESS, locale="nl-BE",
            viewport={"width": 1280, "height": 900})
        self._page = self._ctx.pages[0] if self._ctx.pages else await self._ctx.new_page()

    async def close(self):
        try:
            if self._ctx:
                await self._ctx.close()
            if self._pw:
                await self._pw.stop()
        except Exception:
            pass
        self._pw = self._ctx = self._page = None

    async def search(self, term: str, sniper: dict, circle) -> list[Listing]:
        async with self._lock:
            await self._ensure()
            loc = (db.get_settings().get("fb_location") or "").strip("/ ")
            base = f"https://www.facebook.com/marketplace/{quote(loc)}/search/" if loc \
                else "https://www.facebook.com/marketplace/search/"
            # Facebook only offers 1, 7 or 30 days
            days = int(sniper.get("lookback_days") or 0)
            fb_days = next((d for d in (1, 7, 30) if d >= max(days, 1)), 30)
            url = (f"{base}?query={quote(term)}&sortBy=creation_time_descend&exact=false"
                   f"&daysSinceListed={fb_days}")
            if sniper.get("max_price"):
                url += f"&maxPrice={int(sniper['max_price'])}"
            if sniper.get("min_price"):
                url += f"&minPrice={int(sniper['min_price'])}"
            page = self._page
            try:
                await page.goto(url, wait_until="domcontentloaded", timeout=30000)
            except Exception as e:
                await self.close()
                raise RuntimeError(f"page load failed: {e}")
            if "/login" in page.url or "checkpoint" in page.url:
                raise Blocked("logged out or checkpoint: run fb_login.bat again")
            try:
                await page.wait_for_selector('a[href*="/marketplace/item/"]', timeout=15000)
            except Exception:
                if await page.query_selector('input[name="email"]'):
                    raise Blocked("not logged in: run fb_login.bat")
                return []  # no results
            await page.mouse.wheel(0, 1500)
            await asyncio.sleep(1.5)
            cards = await page.evaluate(EXTRACT_JS)
            out = []
            for c in cards:
                try:
                    item = parse_card(c)
                    item.extra["max_age_days"] = fb_days  # Facebook already filtered on age
                    out.append(item)
                except Exception as e:
                    log.debug("parse error: %s", e)
            return out
