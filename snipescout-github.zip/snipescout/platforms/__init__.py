from dataclasses import dataclass, field


class PlatformError(Exception):
    """Known platform problem (e.g. API changed). Logged as one line, without a traceback."""


class Blocked(Exception):
    """Platform is blocking us (403/429/captcha). The scheduler slows down."""


@dataclass
class Listing:
    uid: str                 # unique across platforms, e.g. 'adv:m123' or 'vinted:456'
    platform: str
    title: str
    url: str
    price: float | None = None
    description: str = ""
    image: str = ""
    location: str = ""
    lat: float | None = None
    lng: float | None = None
    condition: str = ""
    posted_at: float | None = None   # unix time, None if unknown
    country: str = ""                # 2-letter code, for platforms that span countries
    extra: dict = field(default_factory=dict)


def build_all():
    from .adevinta import Adevinta
    from .vinted import Vinted
    from .facebook import Facebook
    return {
        "2dehands": Adevinta("2dehands", "https://www.2dehands.be", "BE"),
        "marktplaats": Adevinta("marktplaats", "https://www.marktplaats.nl", "NL"),
        "vinted": Vinted(),
        "facebook": Facebook(),
    }
