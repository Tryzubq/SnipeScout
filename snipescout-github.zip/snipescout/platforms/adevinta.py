"""2dehands.be and Marktplaats.nl: same backend, internal JSON API /lrp/api/search.
Unofficial: fields can change, so everything is read defensively."""
import logging
import re
from datetime import date, datetime, timedelta
from datetime import time as dtime

from .. import geo
from ..net import Client
from . import Blocked, Listing

log = logging.getLogger("adevinta")

# Distances the site itself offers (km). Other values are sometimes ignored.
DISTANCES = [3, 5, 10, 15, 25, 50, 75, 100, 150, 200, 250]


def _img(item: dict) -> str:
    pics = item.get("pictures") or []
    if pics and isinstance(pics[0], dict):
        for k in ("extraExtraLargeUrl", "extraLargeUrl", "largeUrl", "mediumUrl"):
            if pics[0].get(k):
                return _abs(pics[0][k])
    urls = item.get("imageUrls") or []
    return _abs(urls[0]) if urls else ""


def _abs(u: str) -> str:
    return "https:" + u if u.startswith("//") else u


MONTHS = {"jan": 1, "feb": 2, "fev": 2, "mrt": 3, "maa": 3, "mar": 3, "apr": 4, "avr": 4, "mei": 5, "mai": 5,
          "may": 5, "jun": 6, "jui": 7, "jul": 7, "aug": 8, "aou": 8, "sep": 9, "okt": 10, "oct": 10,
          "nov": 11, "dec": 12}
RELATIVE = {"vandaag": 0, "today": 0, "aujourd'hui": 0, "gisteren": 1, "yesterday": 1, "hier": 1,
            "eergisteren": 2, "avant-hier": 2}


def _end_of_day(d: date) -> float:
    # only the day is known: take the end of that day, so 'posted in the last X days' is not too strict
    return datetime.combine(d, dtime(23, 59, 59)).timestamp()


def parse_date(value, today: date | None = None) -> float | None:
    """Turn the date field into unix time. The site sends text such as
    'Vandaag', 'Gisteren', '31 okt 26' or '6 nov'; sometimes an ISO date or epoch ms."""
    if not value:
        return None
    if isinstance(value, (int, float)):
        return value / 1000 if value > 1e11 else float(value)
    text = str(value).strip()
    try:
        return datetime.fromisoformat(text.replace("Z", "+00:00")).timestamp()
    except ValueError:
        pass
    today = today or date.today()
    low = text.lower().strip(" .")
    if low in RELATIVE:
        return _end_of_day(today - timedelta(days=RELATIVE[low]))
    m = re.match(r"^(\d{1,2})\s+([a-zéû]+)\.?\s*'?(\d{2,4})?$", low)
    if not m:
        return None
    month = MONTHS.get(m.group(2)[:3].replace("é", "e").replace("û", "u"))
    if not month:
        return None
    day = int(m.group(1))
    if m.group(3):
        year = int(m.group(3))
        year += 2000 if year < 100 else 0
    else:
        year = today.year
        if (month, day) > (today.month, today.day):  # e.g. '28 dec' seen in January
            year -= 1
    try:
        return _end_of_day(date(year, month, day))
    except ValueError:
        return None


class Adevinta:
    def __init__(self, key: str, base: str, country: str):
        self.key, self.base, self.country = key, base, country
        self.client = Client()

    async def search(self, term: str, sniper: dict, circle) -> list[Listing] | None:
        anchor = geo.anchor_postcode(self.country, circle) if geo._places else None
        if geo._places and anchor is None:
            return None  # zone is not in this country
        params = {
            "query": term,
            "limit": 50,
            "offset": 0,
            "sortBy": "SORT_INDEX",
            "sortOrder": "DECREASING",
            "viewOptions": "list-view",
        }
        if anchor:
            postcode, km = anchor
            dist = next((d for d in DISTANCES if d >= km), None)
            if dist:
                params["postcode"] = postcode
                params["distanceMeters"] = dist * 1000
        r = await self.client.get(f"{self.base}/lrp/api/search", params=params,
                                  headers={"Accept": "application/json", "Referer": self.base + "/"})
        if r.status_code in (403, 429):
            raise Blocked(f"HTTP {r.status_code}")
        r.raise_for_status()
        data = r.json()
        out = []
        if data.get("listings") and not getattr(self, "_date_logged", False):
            self._date_logged = True
            log.info("%s date field example: %r", self.key, data["listings"][0].get("date"))
        for it in data.get("listings", []):
            try:
                out.append(self._parse(it))
            except Exception as e:
                log.debug("parse error %s: %s", self.key, e)
        return out

    def _parse(self, it: dict) -> Listing:
        pi = it.get("priceInfo") or {}
        cents = pi.get("priceCents")
        ptype = (pi.get("priceType") or "").upper()
        price = None
        if ptype == "FREE":
            price = 0.0
        elif cents and ptype in ("FIXED", "MIN_BID", "FAST_BID", ""):
            price = cents / 100
        loc = it.get("location") or {}
        url = it.get("vipUrl") or it.get("selfLink") or ""
        if url.startswith("/"):
            url = self.base + url
        desc = it.get("description") or it.get("categorySpecificDescription") or ""
        cond = ""
        for a in it.get("attributes") or []:
            if a.get("key") in ("condition", "staat"):
                cond = a.get("value", "")
        return Listing(
            uid=f"adv:{it['itemId']}",
            platform=self.key,
            title=it.get("title", ""),
            url=url,
            price=price,
            description=desc,
            image=_img(it),
            location=loc.get("cityName", ""),
            lat=loc.get("latitude") or None,
            lng=loc.get("longitude") or None,
            condition=cond,
            posted_at=parse_date(it.get("date")),
            extra={"priceType": ptype, "priority": it.get("priorityProduct")},
        )
