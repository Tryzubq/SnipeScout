"""Vinted across several countries that ship to Belgium.

Since September 2026 the catalogue lives at api.vinted.<tld>/svc-catalogue/items;
the old www.vinted.<tld>/api/v2/catalog/items returns 404 for everyone.
The www host hands out an anonymous bearer token (cookie access_token_web), no account needed.

Vinted shares one cross-border catalogue, so the same item often shows up on several
domains. Items are deduplicated by their id, which is the same everywhere.
"""
import asyncio
import logging
import random
import time

from .. import config
from ..net import Client
from . import Blocked, Listing, PlatformError

log = logging.getLogger("vinted")

FAILS_BEFORE_SKIP = 3        # consecutive failures before a country is paused
SKIP_MINUTES = 30            # how long a failing country is paused


def _price(it: dict) -> float | None:
    p = it.get("price")
    if isinstance(p, dict):
        p = p.get("amount")
    try:
        return float(p)
    except (TypeError, ValueError):
        return None


def _posted(it: dict) -> float | None:
    """Upload time of the main photo, if Vinted still sends it (often missing now)."""
    photo = it.get("photo") or {}
    ts = (photo.get("high_resolution") or {}).get("timestamp")
    try:
        return float(ts) if ts else None
    except (TypeError, ValueError):
        return None


def _box(it: dict) -> tuple[str, str, str]:
    """Brand, size and condition. Older responses have brand_title/size_title,
    newer ones put them in item_box: first_line = brand, second_line = 'size · condition'."""
    box = it.get("item_box") or {}
    brand = it.get("brand_title") or ""
    if not brand and box.get("first_line") and box.get("first_line") != it.get("title"):
        brand = box["first_line"]
    size, cond = it.get("size_title") or "", it.get("status") or ""
    second = box.get("second_line") or ""
    if second:
        parts = [p.strip() for p in second.split("·")]
        if len(parts) >= 2:
            size, cond = size or parts[0], cond or parts[-1]
        else:
            cond = cond or parts[0]
    return brand, size, cond


class Site:
    """One Vinted country domain with its own session and anonymous token."""

    def __init__(self, code: str, host: str):
        self.code, self.host = code, host
        self.base = f"https://{host}"
        self.api = f"https://{host.replace('www.', 'api.', 1)}"
        self.client = Client()
        self.token = self.anon = None
        self.primed_at = 0.0
        self.fails = 0
        self.skip_until = 0.0
        self.last_error = ""

    async def prime(self):
        self.client.reset()
        r = await self.client.get(self.base + "/", headers={"Accept": "text/html"})
        if r.status_code in (403, 429):
            raise Blocked(f"homepage HTTP {r.status_code}")
        jar = self.client.session.cookies
        self.token = jar.get("access_token_web")
        self.anon = jar.get("anon_id")
        if not self.token:
            raise PlatformError("no access token (site may have changed)")
        self.primed_at = time.time()

    def headers(self) -> dict:
        h = {"Accept": "application/json", "Authorization": f"Bearer {self.token}",
             "Origin": self.base, "Referer": self.base + "/"}
        if self.anon:
            h["x-anon-id"] = self.anon
        return h

    async def search(self, term: str, sniper: dict) -> list[dict]:
        if not self.token or time.time() - self.primed_at > 1800:  # new token every half hour
            await self.prime()
        params = {"search_text": term, "order": "newest_first", "per_page": 48, "page": 1,
                  "currency": "EUR", "time": int(time.time())}
        # only send price filters when set: blank values give HTTP 400
        if sniper.get("max_price"):
            params["price_to"] = int(sniper["max_price"])
        if sniper.get("min_price"):
            params["price_from"] = int(sniper["min_price"])
        url = self.api + "/svc-catalogue/items"
        r = await self.client.get(url, params=params, headers=self.headers())
        if r.status_code in (401, 403):  # token expired or refused: try once with a fresh one
            await self.prime()
            r = await self.client.get(url, params=params, headers=self.headers())
        if r.status_code in (403, 429):
            self.token = None
            raise Blocked(f"HTTP {r.status_code}")
        if r.status_code != 200:
            raise PlatformError(f"HTTP {r.status_code} (Vinted may have changed its API again)")
        return r.json().get("items", [])


class Vinted:
    key = "vinted"

    def __init__(self):
        self.sites = {code: Site(code, host) for code, (host, _) in config.VINTED_SITES.items()}
        self.settings: dict = {}

    def configure(self, settings: dict):
        """Called by the scheduler before each round, so country choices apply right away."""
        self.settings = settings

    def enabled_codes(self, settings: dict) -> list[str]:
        want = settings.get("vinted_countries") or list(config.VINTED_SITES)
        return [c for c in want if c in self.sites]

    def status_note(self) -> str:
        paused = [f"{c.upper()} ({s.last_error})" for c, s in self.sites.items()
                  if s.skip_until > time.time()]
        return "paused: " + ", ".join(paused) if paused else ""

    async def search(self, term: str, sniper: dict, circle) -> list[Listing]:
        settings_codes = self.enabled_codes(self.settings)
        now = time.time()
        codes = [c for c in settings_codes if self.sites[c].skip_until <= now]
        if not codes:
            if settings_codes:
                raise PlatformError("all selected countries are paused · " + self.status_note())
            raise PlatformError("no Vinted countries selected (Settings > Vinted)")

        out: list[Listing] = []
        seen_ids: set = set()
        errors, ok = [], 0
        for i, code in enumerate(codes):
            site = self.sites[code]
            if i:
                await asyncio.sleep(random.uniform(1.5, 3.5))  # human pace between countries
            try:
                items = await site.search(term, sniper)
            except Exception as e:
                site.fails += 1
                site.last_error = str(e)[:60]
                if site.fails >= FAILS_BEFORE_SKIP:
                    site.skip_until = time.time() + SKIP_MINUTES * 60
                    log.warning("Vinted %s failing (%s), pausing it for %d min",
                                code.upper(), site.last_error, SKIP_MINUTES)
                errors.append(f"{code.upper()}: {site.last_error}")
                continue
            site.fails, site.last_error = 0, ""
            ok += 1
            for it in items:
                try:
                    if it["id"] in seen_ids:
                        continue           # same item on another Vinted domain
                    seen_ids.add(it["id"])
                    out.append(self._parse(it, site))
                except Exception as e:
                    log.debug("parse error: %s", e)

        if not ok:
            raise PlatformError("all countries failed · " + " · ".join(errors[:3]))
        if errors:
            log.info("Vinted: %d/%d countries ok (%s)", ok, len(codes), "; ".join(errors[:3]))
        return out

    def _parse(self, it: dict, site: Site) -> Listing:
        photo = it.get("photo") or {}
        link = it.get("url") or f"/items/{it['id']}"
        if link.startswith("/"):
            link = site.base + link
        brand, size, cond = _box(it)
        return Listing(
            uid=f"vinted:{it['id']}",
            platform=self.key,
            title=it.get("title", ""),
            url=link,
            price=_price(it),
            description=" ".join(x for x in (brand, size) if x),
            image=photo.get("full_size_url") or photo.get("url") or "",
            location=config.VINTED_SITES[site.code][1],
            condition=cond,
            posted_at=_posted(it),
            country=site.code,
        )
