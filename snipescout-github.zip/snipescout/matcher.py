"""Processes search results: new? age, filters, zone, Gemini, score, alert."""
import logging
import time

from . import ai, config, db, geo, telegram
from .geo import norm

log = logging.getLogger("matcher")

DAY = 86400


def rule_score(price: float | None, max_price: float | None, median: float | None) -> int | None:
    """Bargain score without AI: price compared to the median and the maximum."""
    if price is None:
        return None
    parts = []
    if median:
        parts.append(10 - (price / median - 0.5) * 10)   # 0.5x median = 10, 1x = 5
    if max_price:
        parts.append(10 - (price / max_price) * 7)        # 0 = 10, max = 3
    if not parts:
        return None
    return max(1, min(10, round(sum(parts) / len(parts))))


def within_days(listing, days: int, now: float | None = None) -> bool | None:
    """True/False if the posting date is known, None if unknown."""
    if listing.posted_at:
        return (now or time.time()) - listing.posted_at <= days * DAY
    if listing.extra.get("max_age_days"):
        return True  # the platform itself already filtered on age (Facebook)
    return None


def matches_terms(sniper: dict, l) -> bool:
    """True if every word of at least one search term appears in the title or description.
    'honda sfx' matches 'Honda SFX50 2T' but not 'Yamaha Aerox' or 'iScooter i9'."""
    text = norm(f"{l.title} {l.description}")
    for term in sniper["terms"]:
        words = [w for w in norm(term).split() if len(w) > 1]
        if words and all(w in text for w in words):
            return True
    return False


def hard_filter(sniper: dict, l) -> str | None:
    """Returns the reason for rejection, or None if the listing passes."""
    if l.price is None:
        if not sniper["include_no_price"]:
            return "no price"
    else:
        if sniper.get("max_price") is not None and l.price > sniper["max_price"]:
            return "too expensive"
        if sniper.get("min_price") is not None and l.price < sniper["min_price"]:
            return "too cheap"
    if sniper.get("strict_match", True) and not matches_terms(sniper, l):
        return "search words not in title"
    text = norm(f"{l.title} {l.description}")
    for w in sniper["exclude"]:
        if w and norm(w) in text:
            return f"contains '{w}'"
    if text.startswith(("gezocht", "gevraagd", "wanted", "gezocht:")):
        return "wanted ad"
    return None


def _bucket(reason: str) -> str:
    """Group detailed reasons for the status overview."""
    if reason.startswith("contains"):
        return "excluded word"
    if reason.startswith("in excluded zone"):
        return "in excluded zone"
    if " km (max " in reason or reason == "outside your zone":
        return "outside radius/zone"
    return reason


async def process(sniper: dict, platform: str, term: str, listings: list, zones: dict, settings: dict,
                  circle, stats=None, verdicts=None) -> int:
    """stats: optional Counter that collects why listings were skipped.
    verdicts: optional dict uid -> (verdict, detail, listing, score) for the Results tab."""
    if stats is None:
        from collections import Counter
        stats = Counter()
    undated = 0
    if verdicts is None:
        verdicts = {}

    def mark(l, bucket, detail="", score=None):
        if bucket != "alert":
            stats[bucket] += 1
        verdicts[l.uid] = (bucket, detail, l, score)
    key = f"{platform}|{term}"
    baseline = key not in sniper["baselined"]
    days = int(sniper.get("lookback_days") or 0)
    sid = sniper["id"]
    found = backfill_sent = 0
    now = time.time()
    for l in listings:
        if l.price:
            db.add_price(sid, l.uid, l.price)
        if db.is_seen(sid, l.uid):
            if l.uid not in verdicts:
                mark(l, "already seen")
            continue
        db.mark_seen(sid, l.uid)

        # fresh: True = within the window, False = too old, None = platform gave no date
        fresh = within_days(l, days, now) if days else None
        if fresh is False:
            mark(l, f"older than {days} day(s)")
            continue  # too old, e.g. a promoted listing that resurfaces
        if baseline and not days:
            mark(l, "first round (remembered)")
            continue  # no backfill asked for: only remember what is already there
        # on a backfill round an unknown date counts as recent: platforms return newest first,
        # so the cap below keeps the newest ones instead of dropping everything

        reason = hard_filter(sniper, l)
        # location
        if not reason and platform != "vinted":
            if l.lat is None and l.location:
                p = geo.lookup(l.location, near=(circle[0], circle[1]))
                if p:
                    l.lat, l.lng = p.lat, p.lng
            if l.lat is not None:
                allowed, detail = geo.location_allowed(l.lat, l.lng, sniper, zones, settings)
                if not allowed:
                    reason = detail
            elif not sniper["allow_unknown_location"]:
                reason = "location unknown"
        if reason:
            mark(l, _bucket(reason), reason)
            log.debug("rejected %s: %s", l.title, reason)
            continue  # hard filters are not stored, otherwise the database fills up

        median = db.median_price(sid)
        score, why = rule_score(l.price, sniper.get("max_price"), median), ""
        # Gemini only scores the price here; whether a listing matches is decided by your own
        # filters above, so a listing is never dropped because of the AI.
        if sniper["use_ai"] and ai.enabled():
            ev = await ai.score(sniper, l, median)
            if ev:
                score, why = ev["score"], ev["reason"]

        if baseline:
            if fresh is None:
                undated += 1
                why = (why + " " if why else "") + f"(no posting date, assumed within {days} days)"
            if backfill_sent >= config.BACKFILL_ALERT_LIMIT:
                db.add_match(sid, l, score, (why + " " if why else "") + "(not sent: too many on first round)",
                             "match")
                mark(l, "not sent (first-round limit)", why, score)
                continue
            backfill_sent += 1
        db.add_match(sid, l, score, why, "match")
        mark(l, "alert", why, score)
        await telegram.notify_match(sniper, l, score, why)
        found += 1
    if baseline:
        db.mark_baselined(sid, key)
        if undated:
            log.info("%s/%s: %d listings had no posting date and were treated as recent",
                     platform, term, undated)
    return found
