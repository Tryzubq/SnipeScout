"""SnipeScout: local sniper for second-hand marketplaces."""
__version__ = "2.3.0"
