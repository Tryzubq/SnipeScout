"""Dashboard + JSON API. Listens on 127.0.0.1 only."""
import time

from starlette.applications import Starlette
from starlette.middleware import Middleware
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import FileResponse, JSONResponse
from starlette.routing import Mount, Route
from starlette.staticfiles import StaticFiles

from . import ai, config, db, geo, telegram

STATIC = config.ROOT / "snipescout" / "static"
SCHEDULER = None  # set by __main__


class LocalOnly(BaseHTTPMiddleware):
    """Protection against other websites controlling your local dashboard
    (DNS rebinding and CSRF): only localhost as Host, and changes only via JSON from the same origin."""

    async def dispatch(self, request: Request, call_next):
        host = (request.headers.get("host") or "").split(":")[0]
        if host not in ("127.0.0.1", "localhost"):
            return JSONResponse({"error": "forbidden host"}, 403)
        if request.method not in ("GET", "HEAD"):
            origin = request.headers.get("origin")
            if origin and origin not in (f"http://127.0.0.1:{config.PORT}", f"http://localhost:{config.PORT}"):
                return JSONResponse({"error": "forbidden origin"}, 403)
            if "application/json" not in (request.headers.get("content-type") or ""):
                return JSONResponse({"error": "JSON expected"}, 415)
        return await call_next(request)


class Invalid(Exception):
    pass


def _num(v, name, lo=0, hi=1_000_000, allow_none=True):
    if v in (None, ""):
        if allow_none:
            return None
        raise Invalid(f"{name} is required")
    try:
        v = float(v)
    except (TypeError, ValueError):
        raise Invalid(f"{name} must be a number")
    if not lo <= v <= hi:
        raise Invalid(f"{name} must be between {lo:g} and {hi:g}")
    return v


def _strlist(v, name, maxn=10, maxlen=60):
    if not isinstance(v, list):
        raise Invalid(f"{name} must be a list")
    out = []
    for x in v[:maxn]:
        x = str(x).strip()[:maxlen]
        if x and x.lower() not in (o.lower() for o in out):
            out.append(x)
    return out


def clean_sniper(d: dict) -> dict:
    zone_ids = {z["id"] for z in db.list_zones()}
    terms = _strlist(d.get("terms", []), "search terms", maxn=8)
    if not terms:
        raise Invalid("at least one search term is needed")
    platforms = [p for p in d.get("platforms", []) if p in config.PLATFORMS]
    if not platforms:
        raise Invalid("choose at least one platform")
    s = {
        "name": (str(d.get("name") or terms[0]).strip())[:80],
        "terms": terms,
        "min_price": _num(d.get("min_price"), "minimum price"),
        "max_price": _num(d.get("max_price"), "maximum price"),
        "exclude": _strlist(d.get("exclude", []), "exclude words", maxn=30),
        "platforms": platforms,
        "include_zones": [int(z) for z in d.get("include_zones", []) if int(z) in zone_ids],
        "exclude_zones": [int(z) for z in d.get("exclude_zones", []) if int(z) in zone_ids],
        "radius_km": _num(d.get("radius_km"), "radius", 1, 300),
        "strict_match": bool(d.get("strict_match", True)),
        "lookback_days": int(_num(d.get("lookback_days"), "days", 0, 30) or 0),
        "allow_unknown_location": bool(d.get("allow_unknown_location", True)),
        "include_no_price": bool(d.get("include_no_price", False)),
        "use_ai": bool(d.get("use_ai", True)),
        "active": bool(d.get("active", True)),
    }
    center = str(d.get("center_query") or "").strip()[:60]
    s["center_label"] = s["center_lat"] = s["center_lng"] = None
    if center and center.lower() not in ("thuis", "home"):
        p = geo.lookup(center)
        if not p:
            raise Invalid(f"'{center}' not found. Try a postcode, e.g. 9000")
        s["center_label"], s["center_lat"], s["center_lng"] = f"{p.name} ({p.postcode})", p.lat, p.lng
    if s["min_price"] is not None and s["max_price"] is not None and s["min_price"] > s["max_price"]:
        raise Invalid("minimum price is higher than maximum price")
    return s


async def body(request: Request) -> dict:
    try:
        d = await request.json()
    except Exception:
        raise Invalid("invalid JSON")
    if not isinstance(d, dict):
        raise Invalid("object expected")
    return d


def api(fn):
    async def wrapper(request: Request):
        try:
            res = await fn(request)
            return JSONResponse(res if res is not None else {"ok": True})
        except Invalid as e:
            return JSONResponse({"error": str(e)}, 400)
    return wrapper


# ---------- routes ----------

async def index(request):
    return FileResponse(STATIC / "index.html")


@api
async def state(request):
    st = {}
    if SCHEDULER:
        for k, v in SCHEDULER.status.items():
            st[k] = {**v, "next_in": max(0, int((v["next_run"] or time.time()) - time.time()))}
    s = db.get_settings()
    return {
        "settings": s,
        "snipers": db.list_snipers(),
        "zones": db.list_zones(),
        "status": st,
        "platforms": config.PLATFORMS,
        "min_interval": config.MIN_INTERVAL,
        "vinted_sites": {c: label for c, (_, label) in config.VINTED_SITES.items()},
        "backfill_limit": config.BACKFILL_ALERT_LIMIT,
        "telegram": {"configured": telegram.enabled(), "linked": bool(s.get("telegram_chat_id")),
                     "pair_code": telegram.PAIR_CODE if not s.get("telegram_chat_id") else None},
        "gemini": {"configured": ai.enabled(), "model": config.GEMINI_MODEL, "busy": ai.busy()},
        "geo_loaded": len(geo._places),
    }


@api
async def create_sniper(request):
    return {"id": db.save_sniper(clean_sniper(await body(request)))}


@api
async def update_sniper(request):
    sid = request.path_params["sid"]
    old = db.get_sniper(sid)
    if not old:
        raise Invalid("sniper not found")
    new = clean_sniper(await body(request))
    db.save_sniper(new, sid)
    if new["lookback_days"] != old["lookback_days"]:
        db.reset_for_backfill(sid)  # first round again with the new number of days


@api
async def toggle_sniper(request):
    d = await body(request)
    db.set_active(request.path_params["sid"], bool(d.get("active")))


@api
async def delete_sniper(request):
    db.delete_sniper(request.path_params["sid"])


@api
async def synonyms(request):
    term = str((await body(request)).get("term", "")).strip()[:60]
    if not term:
        raise Invalid("enter a search term")
    if not ai.enabled():
        raise Invalid("no GEMINI_API_KEY in .env")
    if ai.busy():
        raise Invalid("Gemini is busy: " + ai.busy())
    terms = await ai.synonyms(term)
    if len(terms) == 1 and ai.busy():
        raise Invalid("Gemini did not answer: " + ai.busy())
    return {"terms": terms}


def _clean_zone(d):
    name = str(d.get("name", "")).strip()[:60] or "Zone"
    kind = d.get("kind")
    if kind not in ("include", "exclude"):
        raise Invalid("type must be include or exclude")
    coords = d.get("coords")
    if not isinstance(coords, list) or not 3 <= len(coords) <= 500:
        raise Invalid("a zone needs 3 to 500 points")
    pts = []
    for p in coords:
        lat, lng = _num(p[0], "lat", -90, 90, False), _num(p[1], "lng", -180, 180, False)
        pts.append([round(lat, 6), round(lng, 6)])
    return name, kind, pts


@api
async def create_zone(request):
    return {"id": db.save_zone(*_clean_zone(await body(request)))}


@api
async def update_zone(request):
    db.save_zone(*_clean_zone(await body(request)), zid=request.path_params["zid"])


@api
async def delete_zone(request):
    db.delete_zone(request.path_params["zid"])


@api
async def matches(request):
    status = request.query_params.get("status", "match")
    if status not in ("match", "rejected"):
        status = "match"
    return {"matches": db.list_matches(status, 200)}


@api
async def results(request):
    """Everything the platforms returned in the last round, per sniper and platform."""
    out = []
    names = {sn["id"]: sn["name"] for sn in db.list_snipers()}
    for (sid, platform), r in (SCHEDULER.results.items() if SCHEDULER else []):
        if sid not in names:
            continue
        out.append({"sniper_id": sid, "sniper_name": names[sid], "platform": platform, **r})
    out.sort(key=lambda x: (x["sniper_id"], x["platform"]))
    return {"results": out}


@api
async def clear_matches(request):
    await body(request)
    db.clear_matches()


@api
async def save_settings(request):
    d = await body(request)
    if "home_query" in d:
        q = str(d["home_query"]).strip()[:60]
        p = geo.lookup(q)
        if not p:
            raise Invalid(f"'{q}' not found in the postcode list")
        db.set_setting("home_query", q)
        db.set_setting("home_lat", p.lat)
        db.set_setting("home_lng", p.lng)
        db.set_setting("home_label", f"{p.name} ({p.postcode}, {p.country})")
    if "default_radius_km" in d:
        db.set_setting("default_radius_km", _num(d["default_radius_km"], "radius", 1, 300, False))
    if "intervals" in d:
        cur = db.get_settings()["intervals"]
        for k, v in (d["intervals"] or {}).items():
            if k in config.PLATFORMS:
                cur[k] = int(_num(v, f"interval {k}", config.MIN_INTERVAL[k], 3600, False))
        db.set_setting("intervals", cur)
    if "vinted_countries" in d:
        codes = [c for c in (d["vinted_countries"] or []) if c in config.VINTED_SITES]
        if not codes:
            raise Invalid("choose at least one Vinted country")
        db.set_setting("vinted_countries", codes)
    if "fb_location" in d:
        loc = str(d["fb_location"]).strip().strip("/")[:60]
        if loc and not all(c.isalnum() or c in "-_" for c in loc):
            raise Invalid("Facebook location: only letters, digits, - and _")
        db.set_setting("fb_location", loc)
    if "paused" in d:
        db.set_setting("paused", bool(d["paused"]))
    if d.get("unlink_telegram"):
        db.set_setting("telegram_chat_id", None)


@api
async def telegram_test(request):
    await body(request)
    if not telegram.enabled():
        raise Invalid("no TELEGRAM_BOT_TOKEN in .env")
    if not telegram.chat_id():
        raise Invalid("not linked yet: first send /start <code> to your bot")
    await telegram.send("🔔 Test alert from SnipeScout. It works!")


@api
async def run_now(request):
    await body(request)
    if SCHEDULER:
        SCHEDULER.run_now()


@api
async def geo_lookup(request):
    p = geo.lookup(request.query_params.get("q", ""))
    if not p:
        raise Invalid("not found")
    return {"name": p.name, "postcode": p.postcode, "country": p.country, "lat": p.lat, "lng": p.lng}


def build_app() -> Starlette:
    routes = [
        Route("/", index),
        Route("/api/state", state),
        Route("/api/snipers", create_sniper, methods=["POST"]),
        Route("/api/snipers/{sid:int}", update_sniper, methods=["PUT"]),
        Route("/api/snipers/{sid:int}", delete_sniper, methods=["DELETE"]),
        Route("/api/snipers/{sid:int}/active", toggle_sniper, methods=["POST"]),
        Route("/api/synonyms", synonyms, methods=["POST"]),
        Route("/api/zones", create_zone, methods=["POST"]),
        Route("/api/zones/{zid:int}", update_zone, methods=["PUT"]),
        Route("/api/zones/{zid:int}", delete_zone, methods=["DELETE"]),
        Route("/api/matches", matches),
        Route("/api/results", results),
        Route("/api/matches/clear", clear_matches, methods=["POST"]),
        Route("/api/settings", save_settings, methods=["POST"]),
        Route("/api/telegram/test", telegram_test, methods=["POST"]),
        Route("/api/run", run_now, methods=["POST"]),
        Route("/api/geo", geo_lookup),
        Mount("/static", StaticFiles(directory=STATIC), name="static"),
    ]
    return Starlette(routes=routes, middleware=[Middleware(LocalOnly)])
