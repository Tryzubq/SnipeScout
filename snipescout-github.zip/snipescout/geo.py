"""Postcodes (GeoNames), distances and zones (polygons)."""
import io
import logging
import math
import unicodedata
import zipfile
from dataclasses import dataclass

from . import config

log = logging.getLogger("geo")

GEONAMES_URL = "https://download.geonames.org/export/zip/{cc}.zip"
COUNTRIES = ("BE", "NL")


@dataclass
class Place:
    country: str
    postcode: str
    name: str
    lat: float
    lng: float


_places: list[Place] = []
_by_postcode: dict[tuple[str, str], Place] = {}
_by_name: dict[str, list[Place]] = {}


def norm(text: str) -> str:
    text = unicodedata.normalize("NFKD", text or "").encode("ascii", "ignore").decode()
    return " ".join(text.lower().replace("-", " ").replace("'", " ").split())


def _download(cc: str) -> None:
    from curl_cffi import requests as creq  # only needed here
    path = config.GEO_DIR / f"{cc}.txt"
    log.info("Downloading postcode list %s from GeoNames...", cc)
    r = creq.get(GEONAMES_URL.format(cc=cc), timeout=60)
    r.raise_for_status()
    with zipfile.ZipFile(io.BytesIO(r.content)) as z:
        path.write_bytes(z.read(f"{cc}.txt"))


def load() -> None:
    config.GEO_DIR.mkdir(parents=True, exist_ok=True)
    _places.clear(); _by_postcode.clear(); _by_name.clear()
    for cc in COUNTRIES:
        path = config.GEO_DIR / f"{cc}.txt"
        if not path.exists():
            try:
                _download(cc)
            except Exception as e:  # without postcodes everything works except zone filtering
                log.error("Downloading postcodes %s failed: %s", cc, e)
                continue
        for line in path.read_text(encoding="utf-8").splitlines():
            p = line.split("\t")
            if len(p) < 11:
                continue
            try:
                pl = Place(p[0], p[1].replace(" ", ""), p[2], float(p[9]), float(p[10]))
            except ValueError:
                continue
            _places.append(pl)
            _by_postcode.setdefault((pl.country, pl.postcode), pl)
            _by_name.setdefault(norm(pl.name), []).append(pl)
    log.info("%d postcodes loaded", len(_places))


def haversine_km(lat1, lng1, lat2, lng2) -> float:
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lng2 - lng1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def lookup(query: str, near: tuple[float, float] | None = None) -> Place | None:
    """Find a place by postcode or name. 'Gent, VOV' works too."""
    if not query:
        return None
    raw = query.strip()
    pc = raw.replace(" ", "").upper()
    if pc[:4].isdigit():
        for cc in COUNTRIES:
            for key in (pc, pc[:4]):
                if (cc, key) in _by_postcode:
                    return _by_postcode[(cc, key)]
    for candidate in (raw, raw.split(",")[0], raw.split("(")[0]):
        hits = _by_name.get(norm(candidate))
        if hits:
            if near and len(hits) > 1:
                return min(hits, key=lambda h: haversine_km(near[0], near[1], h.lat, h.lng))
            return hits[0]
    return None


def point_in_polygon(lat: float, lng: float, poly: list) -> bool:
    """Ray casting. poly = [[lat,lng], ...]"""
    inside = False
    n = len(poly)
    j = n - 1
    for i in range(n):
        yi, xi = poly[i]
        yj, xj = poly[j]
        if (yi > lat) != (yj > lat) and lng < (xj - xi) * (lat - yi) / ((yj - yi) or 1e-12) + xi:
            inside = not inside
        j = i
    return inside


def center_of(sniper: dict, settings: dict) -> tuple[float, float]:
    """Center for 'radius around': the sniper's own place, otherwise home."""
    if sniper.get("center_lat") is not None and sniper.get("center_lng") is not None:
        return sniper["center_lat"], sniper["center_lng"]
    return settings["home_lat"], settings["home_lng"]


def search_circle(sniper: dict, zones: dict[int, dict], settings: dict) -> tuple[float, float, float]:
    """Circle (lat, lng, radius km) that covers all include zones of a sniper."""
    pts = [pt for zid in sniper["include_zones"] if zid in zones for pt in zones[zid]["coords"]]
    if not pts:
        r = sniper.get("radius_km") or settings["default_radius_km"]
        clat, clng = center_of(sniper, settings)
        return clat, clng, float(r)
    lats, lngs = [p[0] for p in pts], [p[1] for p in pts]
    clat, clng = (min(lats) + max(lats)) / 2, (min(lngs) + max(lngs)) / 2
    r = max(haversine_km(clat, clng, p[0], p[1]) for p in pts)
    return clat, clng, r + 1


def anchor_postcode(country: str, circle: tuple[float, float, float]) -> tuple[str, int] | None:
    """Postcode in `country` to search from + radius in km that covers the whole circle.
    None if that country is not inside the circle (searching there is pointless)."""
    clat, clng, r = circle
    best, best_d = None, 1e9
    for p in _places:
        if p.country != country:
            continue
        d = haversine_km(clat, clng, p.lat, p.lng)
        if d < best_d:
            best, best_d = p, d
    if best is None:
        return None
    if best_d > r + 3:  # small margin: postcodes are town centers
        return None
    return best.postcode, math.ceil(best_d + r)


def location_allowed(lat, lng, sniper: dict, zones: dict[int, dict], settings: dict) -> tuple[bool, str]:
    inc = [zones[z] for z in sniper["include_zones"] if z in zones]
    exc = [zones[z] for z in sniper["exclude_zones"] if z in zones]
    if inc:
        if not any(point_in_polygon(lat, lng, z["coords"]) for z in inc):
            return False, "outside your zone"
    else:
        r = sniper.get("radius_km") or settings["default_radius_km"]
        clat, clng = center_of(sniper, settings)
        d = haversine_km(clat, clng, lat, lng)
        if d > r:
            return False, f"{d:.0f} km (max {r:.0f})"
    for z in exc:
        if point_in_polygon(lat, lng, z["coords"]):
            return False, f"in excluded zone {z['name']}"
    return True, ""
