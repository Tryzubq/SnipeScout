"""HTTP via curl_cffi (looks like Chrome, fewer blocks).
Synchronous in a thread, so it also works next to Playwright on Windows."""
import asyncio

from curl_cffi import requests as creq

UA_HEADERS = {
    "Accept-Language": "nl-BE,nl;q=0.9,en;q=0.8",
}


class Client:
    def __init__(self, impersonate: str = "chrome"):
        self.session = creq.Session(impersonate=impersonate, headers=UA_HEADERS, timeout=25)
        self._lock = asyncio.Lock()

    async def request(self, method: str, url: str, **kw):
        async with self._lock:  # Session is not thread-safe
            return await asyncio.to_thread(self.session.request, method, url, **kw)

    async def get(self, url: str, **kw):
        return await self.request("GET", url, **kw)

    async def post(self, url: str, **kw):
        return await self.request("POST", url, **kw)

    def reset(self):
        self.session.cookies.clear()
