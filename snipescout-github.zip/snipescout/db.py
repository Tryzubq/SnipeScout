"""SQLite storage. Low volume, so a single connection with a lock is enough."""
import json
import sqlite3
import statistics
import threading
import time
from copy import deepcopy

from . import config

_lock = threading.RLock()
_conn: sqlite3.Connection | None = None

SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS snipers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    terms TEXT NOT NULL,              -- JSON list of search terms
    min_price REAL,
    max_price REAL,
    exclude TEXT NOT NULL DEFAULT '[]',
    platforms TEXT NOT NULL,
    include_zones TEXT NOT NULL DEFAULT '[]',
    exclude_zones TEXT NOT NULL DEFAULT '[]',
    radius_km REAL,
    center_label TEXT, center_lat REAL, center_lng REAL,
    lookback_days INTEGER NOT NULL DEFAULT 0,
    strict_match INTEGER NOT NULL DEFAULT 1,
    allow_unknown_location INTEGER NOT NULL DEFAULT 1,
    include_no_price INTEGER NOT NULL DEFAULT 0,
    use_ai INTEGER NOT NULL DEFAULT 1,
    active INTEGER NOT NULL DEFAULT 1,
    baselined TEXT NOT NULL DEFAULT '[]',
    created_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS zones (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    kind TEXT NOT NULL CHECK (kind IN ('include','exclude')),
    coords TEXT NOT NULL              -- JSON [[lat,lng], ...]
);
CREATE TABLE IF NOT EXISTS seen (
    sniper_id INTEGER NOT NULL,
    uid TEXT NOT NULL,
    ts REAL NOT NULL,
    PRIMARY KEY (sniper_id, uid)
);
CREATE TABLE IF NOT EXISTS prices (
    sniper_id INTEGER NOT NULL,
    uid TEXT NOT NULL,
    price REAL NOT NULL,
    ts REAL NOT NULL,
    PRIMARY KEY (sniper_id, uid)
);
CREATE TABLE IF NOT EXISTS matches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sniper_id INTEGER NOT NULL,
    uid TEXT NOT NULL,
    platform TEXT NOT NULL,
    title TEXT, price REAL, url TEXT, image TEXT, location TEXT,
    score INTEGER, reason TEXT,
    status TEXT NOT NULL,             -- 'match' or 'rejected'
    ts REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_matches_ts ON matches(ts DESC);
"""

SNIPER_JSON = ("terms", "exclude", "platforms", "include_zones", "exclude_zones", "baselined")
SNIPER_BOOL = ("strict_match", "allow_unknown_location", "include_no_price", "use_ai", "active")


def conn() -> sqlite3.Connection:
    global _conn
    if _conn is None:
        # take over the database of the old Koopjesradar version
        if config.LEGACY_DB_PATH.exists() and not config.DB_PATH.exists():
            for suffix in ("", "-wal", "-shm"):
                old = config.LEGACY_DB_PATH.with_name(config.LEGACY_DB_PATH.name + suffix)
                if old.exists():
                    old.rename(config.DB_PATH.with_name(config.DB_PATH.name + suffix))
        _conn = sqlite3.connect(config.DB_PATH, check_same_thread=False)
        _conn.row_factory = sqlite3.Row
        _conn.execute("PRAGMA journal_mode=WAL")
        _conn.executescript(SCHEMA)
        # migrations for older databases
        cols = {r[1] for r in _conn.execute("PRAGMA table_info(snipers)")}
        for c, t in (("center_label", "TEXT"), ("center_lat", "REAL"), ("center_lng", "REAL"),
                     ("lookback_days", "INTEGER NOT NULL DEFAULT 0"),
                     ("strict_match", "INTEGER NOT NULL DEFAULT 1")):
            if c not in cols:
                _conn.execute(f"ALTER TABLE snipers ADD COLUMN {c} {t}")
        # 2.3: the two Vinted platforms became one multi-country platform
        rows = _conn.execute("SELECT id, platforms FROM snipers").fetchall()
        for sid, raw in rows:
            try:
                plats = json.loads(raw)
            except (TypeError, ValueError):
                continue
            if any(p.startswith("vinted_") for p in plats):
                fixed, seen_p = [], set()
                for p in plats:
                    p = "vinted" if p.startswith("vinted_") else p
                    if p not in seen_p:
                        seen_p.add(p)
                        fixed.append(p)
                _conn.execute("UPDATE snipers SET platforms=? WHERE id=?", (json.dumps(fixed), sid))
        _conn.commit()
    return _conn


def q(sql: str, args=()) -> list[sqlite3.Row]:
    with _lock:
        cur = conn().execute(sql, args)
        rows = cur.fetchall()
        conn().commit()
        return rows


def ex(sql: str, args=()) -> int:
    with _lock:
        cur = conn().execute(sql, args)
        conn().commit()
        return cur.lastrowid


# ---------- settings ----------

def get_settings() -> dict:
    s = deepcopy(config.DEFAULT_SETTINGS)
    for r in q("SELECT key, value FROM settings"):
        s[r["key"]] = json.loads(r["value"])
    # always give new platforms an interval
    for k, v in config.DEFAULT_SETTINGS["intervals"].items():
        s["intervals"].setdefault(k, v)
    return s


def set_setting(key: str, value) -> None:
    ex("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
       (key, json.dumps(value)))


# ---------- snipers ----------

def _sniper(row: sqlite3.Row) -> dict:
    d = dict(row)
    for k in SNIPER_JSON:
        d[k] = json.loads(d[k])
    for k in SNIPER_BOOL:
        d[k] = bool(d[k])
    return d


def list_snipers(active_only=False) -> list[dict]:
    sql = "SELECT * FROM snipers" + (" WHERE active=1" if active_only else "") + " ORDER BY id"
    return [_sniper(r) for r in q(sql)]


def get_sniper(sid: int) -> dict | None:
    rows = q("SELECT * FROM snipers WHERE id=?", (sid,))
    return _sniper(rows[0]) if rows else None


def save_sniper(data: dict, sid: int | None = None) -> int:
    fields = ["name", "terms", "min_price", "max_price", "exclude", "platforms", "include_zones",
              "exclude_zones", "radius_km", "center_label", "center_lat", "center_lng", "lookback_days", "strict_match", "allow_unknown_location", "include_no_price", "use_ai", "active"]
    vals = []
    for f in fields:
        v = data.get(f)
        if f == "lookback_days":
            v = int(v or 0)
        elif f == "strict_match":
            v = int(v is None or bool(v))  # default on
        elif f in SNIPER_JSON:
            v = json.dumps(v or [])
        elif f in SNIPER_BOOL:
            v = int(bool(v))
        vals.append(v)
    if sid is None:
        return ex(f"INSERT INTO snipers({','.join(fields)},created_at) VALUES({','.join('?' * len(fields))},?)",
                  (*vals, time.time()))
    ex(f"UPDATE snipers SET {','.join(f + '=?' for f in fields)} WHERE id=?", (*vals, sid))
    return sid


def set_active(sid: int, active: bool) -> None:
    ex("UPDATE snipers SET active=? WHERE id=?", (int(active), sid))


def delete_sniper(sid: int) -> None:
    for t in ("seen", "prices", "matches"):
        ex(f"DELETE FROM {t} WHERE sniper_id=?", (sid,))
    ex("DELETE FROM snipers WHERE id=?", (sid,))


def mark_baselined(sid: int, key: str) -> None:
    with _lock:
        s = get_sniper(sid)
        if s and key not in s["baselined"]:
            s["baselined"].append(key)
            ex("UPDATE snipers SET baselined=? WHERE id=?", (json.dumps(s["baselined"]), sid))


# ---------- zones ----------

def list_zones() -> list[dict]:
    return [{**dict(r), "coords": json.loads(r["coords"])} for r in q("SELECT * FROM zones ORDER BY id")]


def save_zone(name: str, kind: str, coords: list, zid: int | None = None) -> int:
    if zid is None:
        return ex("INSERT INTO zones(name,kind,coords) VALUES(?,?,?)", (name, kind, json.dumps(coords)))
    ex("UPDATE zones SET name=?, kind=?, coords=? WHERE id=?", (name, kind, json.dumps(coords), zid))
    return zid


def delete_zone(zid: int) -> None:
    ex("DELETE FROM zones WHERE id=?", (zid,))
    # remove the zone from snipers too
    for s in list_snipers():
        changed = False
        for k in ("include_zones", "exclude_zones"):
            if zid in s[k]:
                s[k].remove(zid)
                changed = True
        if changed:
            save_sniper(s, s["id"])


# ---------- seen / prices / matches ----------

def is_seen(sid: int, uid: str) -> bool:
    return bool(q("SELECT 1 FROM seen WHERE sniper_id=? AND uid=?", (sid, uid)))


def mark_seen(sid: int, uid: str) -> None:
    ex("INSERT OR IGNORE INTO seen(sniper_id,uid,ts) VALUES(?,?,?)", (sid, uid, time.time()))


def add_price(sid: int, uid: str, price: float) -> None:
    ex("INSERT OR REPLACE INTO prices(sniper_id,uid,price,ts) VALUES(?,?,?,?)", (sid, uid, price, time.time()))


def median_price(sid: int) -> float | None:
    rows = q("SELECT price FROM prices WHERE sniper_id=? AND price>0 ORDER BY ts DESC LIMIT 300", (sid,))
    vals = [r["price"] for r in rows]
    return statistics.median(vals) if len(vals) >= 5 else None


def add_match(sid: int, listing, score, reason, status) -> int:
    return ex("INSERT INTO matches(sniper_id,uid,platform,title,price,url,image,location,score,reason,status,ts)"
              " VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
              (sid, listing.uid, listing.platform, listing.title, listing.price, listing.url, listing.image,
               listing.location, score, reason, status, time.time()))


def list_matches(status: str = "match", limit: int = 100) -> list[dict]:
    rows = q("SELECT m.*, s.name AS sniper_name FROM matches m LEFT JOIN snipers s ON s.id=m.sniper_id"
             " WHERE m.status=? ORDER BY m.ts DESC LIMIT ?", (status, limit))
    return [dict(r) for r in rows]


def clear_matches() -> None:
    ex("DELETE FROM matches")


def prune(days: int = 60) -> None:
    # 'seen' is never pruned: otherwise old promoted listings would trigger alerts again
    cutoff = time.time() - days * 86400
    for t in ("prices", "matches"):
        ex(f"DELETE FROM {t} WHERE ts<?", (cutoff,))


def reset_for_backfill(sid: int) -> None:
    """After changing 'posted in the last X days': run the first round again,
    without alerting listings that were already alerted before."""
    ex("DELETE FROM seen WHERE sniper_id=? AND uid NOT IN (SELECT uid FROM matches WHERE sniper_id=?)", (sid, sid))
    ex("UPDATE snipers SET baselined='[]' WHERE id=?", (sid,))
