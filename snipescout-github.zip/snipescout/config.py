"""Configuration from .env (secrets) and paths."""
import os
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
DATA_DIR.mkdir(exist_ok=True)

load_dotenv(ROOT / ".env")


def _int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, default))
    except ValueError:
        return default


TELEGRAM_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-flash-latest").strip()
GEMINI_THINKING = os.getenv("GEMINI_THINKING", "low").strip().lower()
GEMINI_RPM = max(1, _int("GEMINI_MAX_PER_MINUTE", 10))
PORT = _int("DASHBOARD_PORT", 8000)
FB_HEADLESS = os.getenv("FB_HEADLESS", "true").lower() != "false"

DB_PATH = DATA_DIR / "snipescout.db"
LEGACY_DB_PATH = DATA_DIR / "radar.db"   # from the old Koopjesradar version
GEO_DIR = DATA_DIR / "geo"
FB_PROFILE_DIR = DATA_DIR / "fb_profile"

# Platforms: key -> display name
PLATFORMS = {
    "2dehands": "2dehands",
    "marktplaats": "Marktplaats",
    "vinted": "Vinted",
    "facebook": "Facebook",
}

# Vinted countries that ship to Belgium: code -> (domain, label)
VINTED_SITES = {
    "be": ("www.vinted.be", "Belgium"),
    "nl": ("www.vinted.nl", "Netherlands"),
    "fr": ("www.vinted.fr", "France"),
    "de": ("www.vinted.de", "Germany"),
    "es": ("www.vinted.es", "Spain"),
    "it": ("www.vinted.it", "Italy"),
    "pt": ("www.vinted.pt", "Portugal"),
    "lu": ("www.vinted.lu", "Luxembourg"),
    "ie": ("www.vinted.ie", "Ireland"),
}

# Minimum interval in seconds per platform (protection against bans)
MIN_INTERVAL = {"2dehands": 20, "marktplaats": 20, "vinted": 60, "facebook": 90}

# On the first round with "posted in the last X days", send at most this many alerts per search term
BACKFILL_ALERT_LIMIT = max(1, _int("BACKFILL_ALERT_LIMIT", 25))

DEFAULT_SETTINGS = {
    "home_query": "Brussel",
    "home_lat": 50.8466,
    "home_lng": 4.3528,
    "home_label": "Brussel (1000)",
    "default_radius_km": 30,
    "intervals": {"2dehands": 60, "marktplaats": 60, "vinted": 240, "facebook": 180},
    "vinted_countries": list(VINTED_SITES),
    "fb_location": "",
    "paused": False,
    "telegram_chat_id": None,
}
