"""One loop per platform. With random pauses and automatic slowdown when blocked."""
import asyncio
import logging
import random
import time
from collections import Counter

from . import config, db, geo, matcher, telegram
from .platforms import Blocked, PlatformError, build_all

log = logging.getLogger("scheduler")

MAX_BACKOFF = 30 * 60


class Scheduler:
    def __init__(self):
        self.platforms = build_all()
        self.status = {k: {"summary": "not run yet", "last_run": None, "error": None, "next_run": None,
                           "backoff": 1, "found": 0, "note": ""} for k in self.platforms}
        self._wake = {k: asyncio.Event() for k in self.platforms}
        self.tasks: list[asyncio.Task] = []
        # last round per (sniper id, platform): everything the platform returned, with a verdict
        self.results: dict[tuple[int, str], dict] = {}

    def start(self):
        for k in self.platforms:
            self.tasks.append(asyncio.create_task(self._loop(k), name=f"loop-{k}"))

    def run_now(self):
        for e in self._wake.values():
            e.set()

    async def stop(self):
        for t in self.tasks:
            t.cancel()
        fb = self.platforms.get("facebook")
        if fb:
            await fb.close()

    async def _loop(self, key: str):
        st = self.status[key]
        plat = self.platforms[key]
        await asyncio.sleep(random.uniform(1, 8))  # do not start everything at once
        while True:
            settings = db.get_settings()
            snipers = [s for s in db.list_snipers(active_only=True) if key in s["platforms"]]
            if settings["paused"]:
                st["summary"] = "paused"
            elif not snipers:
                st["summary"] = "no active snipers"
            else:
                await self._round(key, plat, snipers, settings, st)
            interval = max(config.MIN_INTERVAL[key], int(settings["intervals"].get(key, 60)))
            wait = interval * st["backoff"] * random.uniform(0.8, 1.2)
            wait = min(wait, MAX_BACKOFF)
            st["next_run"] = time.time() + wait
            self._wake[key].clear()
            try:
                await asyncio.wait_for(self._wake[key].wait(), timeout=wait)
            except asyncio.TimeoutError:
                pass

    async def _round(self, key, plat, snipers, settings, st):
        if hasattr(plat, "configure"):
            plat.configure(settings)
        zones = {z["id"]: z for z in db.list_zones()}
        found = requests = results = 0
        stats = Counter()
        try:
            for s in snipers:
                circle = geo.search_circle(s, zones, settings)
                verdicts: dict = {}
                skipped_country = True
                for term in s["terms"]:
                    if requests:
                        await asyncio.sleep(random.uniform(2, 5))  # human pace
                    requests += 1
                    listings = await plat.search(term, s, circle)
                    if listings is None:
                        continue  # zone is not in this platform's country
                    skipped_country = False
                    results += len(listings)
                    found += await matcher.process(s, key, term, listings, zones, settings, circle, stats,
                                                   verdicts)
                self.results[(s["id"], key)] = {
                    "ts": time.time(),
                    "note": "zone is not in this platform's country" if skipped_country else "",
                    "items": [{"uid": l.uid, "title": l.title, "price": l.price, "url": l.url, "image": l.image,
                               "location": l.location, "posted_at": l.posted_at, "verdict": v, "detail": d,
                               "score": sc} for v, d, l, sc in verdicts.values()],
                }
            note = plat.status_note() if hasattr(plat, "status_note") else ""
            st.update(last_run=time.time(), error=None, found=st["found"] + found, note=note,
                      summary=f"OK at {time.strftime('%H:%M:%S')}: {requests} searches, {results} results, {found} alerts"
                              + (" · skipped: " + ", ".join(f"{n} {why}" for why, n in stats.most_common(4))
                                 if stats else "") + (" · " + note if note else ""))
            if st["backoff"] > 1:
                st["backoff"] = max(1, st["backoff"] / 2)
        except Blocked as e:
            await self._fail(key, st, f"blocked: {e}", blocked=True)
        except PlatformError as e:
            await self._fail(key, st, str(e)[:200])
        except asyncio.CancelledError:
            raise
        except Exception as e:
            log.exception("error at %s", key)
            await self._fail(key, st, str(e)[:200])

    async def _fail(self, key, st, msg, blocked=False):
        old = st["backoff"]
        st["backoff"] = min(old * 2, 16)
        st["error"] = msg
        st["last_run"] = time.time()
        st["summary"] = f"ERROR at {time.strftime('%H:%M:%S')}: {msg} (slowed down x{st['backoff']:.0f})"
        log.warning("%s: %s", key, msg)
        # one alert when the platform first slows down a lot
        if blocked and old < 4 <= st["backoff"]:
            await telegram.send(f"⚠️ {config.PLATFORMS[key]} is blocking or failing: {msg}\n"
                                f"I am searching there more slowly now. Check the dashboard.")
